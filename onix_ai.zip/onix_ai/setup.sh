#!/usr/bin/env bash
# Run once inside the onix_ai folder: generates Android scaffold, then overlays ONIX files.
set -e
flutter create --org com.example --project-name onix_ai --platforms android .
cp -r overlay/android/. android/
flutter pub get
echo "Done. Build with: flutter build apk --debug"
