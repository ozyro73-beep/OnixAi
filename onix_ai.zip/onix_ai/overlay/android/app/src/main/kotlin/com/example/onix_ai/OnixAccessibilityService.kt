package com.example.onix_ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Acts ONLY when the app calls it after a user command. Never reads/writes password fields. */
class OnixAccessibilityService : AccessibilityService() {
    companion object { var instance: OnixAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun clickableAncestor(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var c = n
        while (c != null) { if (c.isClickable) return c; c = c.parent }
        return null
    }

    fun clickText(text: String): String {
        val root = rootInActiveWindow ?: return "no_window"
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            // Do not mistake the text currently typed into a search box for a result row.
            if (n.isEditable) continue
            val t = clickableAncestor(n)
            if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok"
        }
        return "not_found"
    }

    private fun findVideo(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = (n.contentDescription?.toString() ?: "").lowercase()
        if (d.contains("play video") || (d.contains(" views") && d.contains(" - "))) {
            val t = clickableAncestor(n)
            if (t != null) return t
        }
        for (i in 0 until n.childCount) {
            val r = findVideo(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    fun clickFirstVideo(guess: Boolean): String {
        val root = rootInActiveWindow ?: return "no_window"
        if (root.packageName?.toString() != "com.google.android.youtube") return "youtube_not_in_front"
        val v = findVideo(root)
        if (v != null && v.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok"
        if (!guess) return "not_found"
        val dm = resources.displayMetrics
        val path = Path()
        path.moveTo(dm.widthPixels * 0.5f, dm.heightPixels * 0.35f)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        return if (dispatchGesture(g, null, null)) "tapped_guess_unverified" else "gesture_failed"
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable && !n.isPassword) return n
        for (i in 0 until n.childCount) {
            val r = findEditable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun looksLikeSearch(n: AccessibilityNodeInfo): Boolean {
        var t = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
        if (Build.VERSION.SDK_INT >= 26) t += " " + (n.hintText?.toString() ?: "")
        t = t.lowercase()
        return t.contains("search") || t.contains("type web address")
    }

    private fun findSearchNode(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (looksLikeSearch(n)) {
            val t = clickableAncestor(n)
            if (t != null) return t
        }
        for (i in 0 until n.childCount) {
            val r = findSearchNode(n.getChild(i))
            if (r != null) return r
        }
        return null
    }

    /** Makes sure a text field exists: returns editable_ready, clicked_search or not_found. */
    fun findOrOpenSearch(): String {
        val root = rootInActiveWindow ?: return "no_window"
        if (findEditable(root) != null) return "editable_ready"
        val s = findSearchNode(root) ?: return "not_found"
        return if (s.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "clicked_search" else "not_found"
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow
        var node = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null || !node.isEditable) node = findEditable(root)
        if (node == null) return "no_focused_field"
        if (node.isPassword) return "blocked_password_field"
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "ok" else "failed"
    }


    private fun findSendButton(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val label = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: ""))
            .lowercase().trim()
        if ((label == "send" || label == "send message" || label == "send button") && n.isEnabled) {
            val target = clickableAncestor(n)
            if (target != null) return target
        }
        for (i in 0 until n.childCount) {
            val found = findSendButton(n.getChild(i))
            if (found != null) return found
        }
        return null
    }

    /** Click only an explicitly labelled send control on the currently visible app. */
    fun clickSendButton(): String {
        val root = rootInActiveWindow ?: return "no_window"
        val button = findSendButton(root) ?: return "send_button_not_found"
        return if (button.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "ok" else "send_click_failed"
    }

    fun submit(): String {
        val root = rootInActiveWindow ?: return "no_window"
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root)
        if (node != null && Build.VERSION.SDK_INT >= 30 &&
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return "ok"
        if (clickText("Search") == "ok" || clickText("Go") == "ok") return "ok"
        return "failed"
    }
}
