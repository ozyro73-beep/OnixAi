package com.example.onix_ai

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

/** Keeps a visible, user-started foreground service alive while ONIX is active. */
class ListenService : Service() {
    private var windowManager: WindowManager? = null
    private var orb: TextView? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        showOrbIfAllowed()
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val ch = "onix_listen"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "ONIX listening", NotificationManager.IMPORTANCE_LOW))
        }
        val tap = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stopIntent = Intent(this, OnixStopReceiver::class.java).setAction(OnixStopReceiver.ACTION_STOP)
        val stopPending = PendingIntent.getBroadcast(this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
        val n = b.setContentTitle("ONIX AI Active")
            .setContentText("Microphone session is active. Tap STOP to end it.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(tap)
            .addAction(android.R.drawable.ic_media_pause, "STOP ONIX", stopPending)
            .setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(42, n)
            showOrbIfAllowed()
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun showOrbIfAllowed() {
        if (orb != null || (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this))) return
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val panel = TextView(this).apply {
                text = "🎙  ONIX LISTENING\nSay ONIX to wake me • STOP to end"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(24, 14, 24, 14)
                background = GradientDrawable().apply {
                    setColor(0xEE17152D.toInt())
                    cornerRadius = 48f
                    setStroke(2, 0xFF8D78FF.toInt())
                }
                elevation = 12f
            }
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                       else WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(300, 76, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = 36
            }
            windowManager?.addView(panel, params)
            orb = panel
        } catch (_: Exception) { orb = null }
    }

    override fun onDestroy() {
        try { orb?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        orb = null
        super.onDestroy()
    }
}
