package com.example.onix_ai

import android.animation.ObjectAnimator
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/** Keeps a visible, user-started foreground service alive while ONIX is active. */
class ListenService : Service() {
    private var windowManager: WindowManager? = null
    private var orb: TextView? = null
    private var pulse: ObjectAnimator? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        showOrbIfAllowed()
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val ch = "onix_listen"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "ONIX listening", NotificationManager.IMPORTANCE_LOW))
        }
        val tap = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stopIntent = Intent(this, OnixStopReceiver::class.java).setAction(OnixStopReceiver.ACTION_STOP)
        val stopPending = PendingIntent.getBroadcast(this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
        val n = b.setContentTitle("ONIX AI Active")
            .setContentText("ONIX voice session is active. Tap STOP to end it.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(tap)
            .addAction(android.R.drawable.ic_media_pause, "STOP ONIX", stopPending)
            .setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(42, n)
            showOrbIfAllowed()
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun showOrbIfAllowed() {
        if (orb != null || (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this))) return
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val bubble = TextView(this).apply {
                text = "✦\nONIX"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    intArrayOf(0xFF00D5FF.toInt(), 0xFF6545E8.toInt(), 0xFF17152D.toInt())).apply {
                    shape = GradientDrawable.OVAL
                    setStroke(3, 0xFFB5F5FF.toInt())
                }
                elevation = 18f
            }
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                       else WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(116, 116, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 24; y = 220
            }
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            bubble.setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true }
                    MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); windowManager?.updateViewLayout(v, params); true }
                    MotionEvent.ACTION_UP -> {
                        if (kotlin.math.abs(event.rawX - downX) < 8 && kotlin.math.abs(event.rawY - downY) < 8) {
                            val open = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            startActivity(open)
                        }
                        true
                    }
                    else -> true
                }
            }
            windowManager?.addView(bubble, params)
            orb = bubble
            pulse = ObjectAnimator.ofFloat(bubble, View.ALPHA, 0.72f, 1f).apply { duration = 1100; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; start() }
        } catch (_: Exception) { orb = null }
    }

    override fun onDestroy() {
        pulse?.cancel(); pulse = null
        try { orb?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        orb = null
        super.onDestroy()
    }
}
