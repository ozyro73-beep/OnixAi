package com.example.onix_ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class OnixStopReceiver : BroadcastReceiver() {
    companion object { const val ACTION_STOP = "com.example.onix_ai.STOP_ONIX" }
    override fun onReceive(context: Context, intent: Intent?) {
        context.stopService(Intent(context, ListenService::class.java))
        val open = Intent(context, MainActivity::class.java).apply {
            action = ACTION_STOP
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        context.startActivity(open)
    }
}
