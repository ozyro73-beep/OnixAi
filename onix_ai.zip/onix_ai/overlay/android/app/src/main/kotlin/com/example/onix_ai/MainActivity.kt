package com.example.onix_ai

import android.content.Context
import android.content.Intent
import android.os.Build
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var controlChannel: MethodChannel? = null
    private var pendingStopRequested = false

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == OnixStopReceiver.ACTION_STOP) {
            pendingStopRequested = true
            controlChannel?.invokeMethod("stopOnix", null)
            intent.action = null
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        controlChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "onix/control")
        if (intent?.action == OnixStopReceiver.ACTION_STOP) pendingStopRequested = true
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "onix/native")
            .setMethodCallHandler { call, result ->
                val svc = OnixAccessibilityService.instance
                when (call.method) {
                    "consumeStopRequest" -> { val pending = pendingStopRequested; pendingStopRequested = false; result.success(pending) }
                    "openApp" -> result.success(openApp(call.argument<String>("name") ?: ""))
                    "openUrl" -> result.success(openUrl(call.argument<String>("url") ?: "", call.argument<String>("package")))
                    "a11yEnabled" -> result.success(svc != null)
                    "openA11ySettings" -> {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        result.success("ok")
                    }
                    "clickText" -> result.success(svc?.clickText(call.argument<String>("text") ?: "") ?: "accessibility_not_enabled")
                    "clickFirstVideo" -> result.success(svc?.clickFirstVideo(call.argument<Boolean>("guess") ?: false) ?: "accessibility_not_enabled")
                    "findOrOpenSearch" -> result.success(svc?.findOrOpenSearch() ?: "accessibility_not_enabled")
                    "submit" -> result.success(svc?.submit() ?: "accessibility_not_enabled")
                    "clickSendButton" -> result.success(svc?.clickSendButton() ?: "accessibility_not_enabled")
                    "startKeepAlive" -> result.success(keepAlive(true))
                    "stopKeepAlive" -> result.success(keepAlive(false))
                    "overlayPermissionGranted" -> result.success(Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))
                    "requestOverlayPermission" -> {
                        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                        result.success("ok")
                    }
                    "typeText" -> result.success(svc?.typeText(call.argument<String>("text") ?: "") ?: "accessibility_not_enabled")
                    else -> result.notImplemented()
                }
            }
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = name.lowercase().trim()
        if (q.isEmpty()) return "not_found"
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "not_found"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "not_launchable"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return "ok"
    }

    private fun openUrl(url: String, pkg: String?): String {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) {
            try { i.setPackage(pkg); startActivity(i); return "ok" } catch (e: Exception) { i.setPackage(null) }
        }
        return try { startActivity(i); "ok" } catch (e: Exception) { "error: ${e.message}" }
    }

    private fun keepAlive(start: Boolean): String = try {
        val i = Intent(this, ListenService::class.java)
        if (start) {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } else stopService(i)
        "ok"
    } catch (e: Exception) { "error: ${e.message}" }

    override fun onDestroy() {
        // The foreground listening service is stopped only by the user's STOP action.
        super.onDestroy()
    }
}
