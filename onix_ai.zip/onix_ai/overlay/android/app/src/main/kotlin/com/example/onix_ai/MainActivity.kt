package com.example.onix_ai

import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "onix/native")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "openApp" -> result.success(openApp(call.argument<String>("name") ?: ""))
                    "openUrl" -> result.success(openUrl(call.argument<String>("url") ?: ""))
                    else -> result.notImplemented()
                }
            }
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = name.lowercase().trim()
        if (q.isEmpty()) return "not_found"
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "not_found"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "not_launchable"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return "ok"
    }

    private fun openUrl(url: String): String = try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        "ok"
    } catch (e: Exception) { "error: ${e.message}" }
}
