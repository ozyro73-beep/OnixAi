"""ONIX AI cloud gateway. Provider credentials stay on the server."""
import os, sqlite3, time
from typing import Optional
import httpx
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="ONIX AI Gateway", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "*").split(","), allow_methods=["POST", "GET"], allow_headers=["*"])
DB = os.getenv("ONIX_DB", "onix_memory.sqlite3")

class ChatRequest(BaseModel):
    user_id: str = Field(min_length=1, max_length=128)
    message: str = Field(min_length=1, max_length=12000)
    system: str = Field(default="You are ONIX, Krishna Mishra's personal AI assistant. Reply naturally in the user's language.", max_length=6000)

class TTSRequest(BaseModel):
    text: str = Field(min_length=1, max_length=5000)
    voice_id: str = Field(min_length=1, max_length=128)

def require_auth(authorization: Optional[str] = Header(default=None)):
    expected = os.getenv("ONIX_ACCESS_TOKEN", "")
    if not expected:
        raise HTTPException(503, "ONIX_ACCESS_TOKEN is not configured on the server")
    supplied = authorization or ""
    if supplied != f"Bearer {expected}":
        raise HTTPException(401, "Invalid ONIX backend token")

def db():
    c = sqlite3.connect(DB)
    c.execute("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, user_id TEXT NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL, created INTEGER NOT NULL)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id, id)")
    return c

async def call_gemini(messages, system):
    key = os.getenv("GEMINI_API_KEY", "")
    model = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
    if not key: raise RuntimeError("GEMINI_API_KEY is not configured on the server")
    contents = []
    for role, content in messages:
        contents.append({"role": "user" if role == "user" else "model", "parts": [{"text": content}]})
    async with httpx.AsyncClient(timeout=75) as client:
        r = await client.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent", headers={"x-goog-api-key": key}, json={"systemInstruction":{"parts":[{"text":system}]},"contents":contents})
    if r.status_code >= 400: raise RuntimeError(f"Gemini {r.status_code}: {r.text[:500]}")
    data = r.json()
    return "".join(p.get("text", "") for p in data.get("candidates", [{}])[0].get("content", {}).get("parts", [])).strip()

async def call_groq(messages, system):
    key = os.getenv("GROQ_API_KEY", "")
    model = os.getenv("GROQ_MODEL", "openai/gpt-oss-20b")
    if not key: raise RuntimeError("GROQ_API_KEY is not configured on the server")
    payload = [{"role":"system","content":system}] + [{"role":r,"content":c} for r,c in messages]
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post("https://api.groq.com/openai/v1/chat/completions", headers={"Authorization":f"Bearer {key}"}, json={"model":model,"messages":payload})
    if r.status_code >= 400: raise RuntimeError(f"Groq {r.status_code}: {r.text[:500]}")
    return (r.json().get("choices", [{}])[0].get("message", {}).get("content") or "").strip()

@app.get("/health")
def health(): return {"status":"ok", "service":"onix-ai-gateway"}

@app.post("/v1/chat")
async def chat(req: ChatRequest, _auth: None = Depends(require_auth)):
    c = db()
    try:
        rows = c.execute("SELECT role, content FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 20", (req.user_id,)).fetchall()
        history = list(reversed(rows)) + [("user", req.message)]
        primary = os.getenv("PRIMARY_PROVIDER", "gemini").lower()
        providers = [call_gemini, call_groq] if primary == "gemini" else [call_groq, call_gemini]
        errors = []
        reply = ""
        for provider in providers:
            try:
                reply = await provider(history, req.system)
                if reply: break
                errors.append("Provider returned empty response")
            except Exception as e: errors.append(str(e))
        if not reply: raise HTTPException(502, "AI providers failed: " + " | ".join(errors))
        now = int(time.time())
        c.execute("INSERT INTO messages(user_id,role,content,created) VALUES(?,?,?,?)", (req.user_id,"user",req.message,now))
        c.execute("INSERT INTO messages(user_id,role,content,created) VALUES(?,?,?,?)", (req.user_id,"assistant",reply,now))
        c.commit()
        return {"reply":reply, "provider":"cloud-gateway"}
    finally: c.close()

@app.post("/v1/tts")
async def tts(req: TTSRequest, _auth: None = Depends(require_auth)):
    key = os.getenv("ELEVENLABS_API_KEY", "")
    if not key: raise HTTPException(503, "ElevenLabs is not configured on the ONIX backend")
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(f"https://api.elevenlabs.io/v1/text-to-speech/{req.voice_id}", headers={"xi-api-key":key,"Content-Type":"application/json","Accept":"audio/mpeg"}, json={"text":req.text,"model_id":os.getenv("ELEVENLABS_MODEL","eleven_multilingual_v2"),"voice_settings":{"stability":0.45,"similarity_boost":0.8}})
    if r.status_code >= 400: raise HTTPException(r.status_code, r.text[:500])
    from fastapi.responses import Response
    return Response(content=r.content, media_type="audio/mpeg")

@app.delete("/v1/memory/{user_id}")
def clear_memory(user_id: str, _auth: None = Depends(require_auth)):
    c = db()
    try:
        c.execute("DELETE FROM messages WHERE user_id=?", (user_id,)); c.commit()
        return {"status":"cleared"}
    finally: c.close()
