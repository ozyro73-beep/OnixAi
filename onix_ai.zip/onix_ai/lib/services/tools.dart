import 'native_bridge.dart';

/// Gemini function declarations + executor. Every result is the REAL outcome.
const toolDeclarations = [
  {
    'name': 'open_app',
    'description': 'Open an installed Android app by its name (e.g. Instagram, WhatsApp, Chrome).',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'name': {'type': 'STRING'}},
      'required': ['name']
    }
  },
  {
    'name': 'web_search',
    'description': 'Search Google in the browser.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'query': {'type': 'STRING'}},
      'required': ['query']
    }
  },
  {
    'name': 'youtube_search',
    'description': 'Search YouTube (songs, videos, artists). Opens results; user picks what to play.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'query': {'type': 'STRING'}},
      'required': ['query']
    }
  },
  {
    'name': 'send_message',
    'description':
        'After the user has explicitly confirmed the exact recipient and message, send it using Android Accessibility. For WhatsApp, set app=WhatsApp and contact to the exact contact name; this opens WhatsApp, searches the contact, opens the chat, types the message and taps the labelled Send button. For Discord or another supported app, set contact to empty to use the currently selected/open conversation and its visible message composer. This works only when the app exposes an accessibility-visible editable composer and a clearly labelled Send button. Never use without explicit user confirmation.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {
        'app': {'type': 'STRING'},
        'contact': {'type': 'STRING'},
        'message': {'type': 'STRING'}
      },
      'required': ['app', 'message']
    }
  },
  {
    'name': 'play_youtube',
    'description':
        'Search YouTube and automatically tap the first result so the song/video starts playing. Use this when the user says play/chalao a song or video. Requires the Accessibility Service.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'query': {'type': 'STRING'}},
      'required': ['query']
    }
  },
  {
    'name': 'click_text',
    'description': 'Tap a button or item on the current screen that shows this text. Requires the Accessibility Service.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'text': {'type': 'STRING'}},
      'required': ['text']
    }
  },
  {
    'name': 'type_text',
    'description': 'Type text into the currently focused text field (never password fields). Requires the Accessibility Service.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'text': {'type': 'STRING'}},
      'required': ['text']
    }
  },
  {
    'name': 'search_in_app',
    'description':
        'Open ANY installed app (Chrome, Google, Instagram, Play Store, etc.), type the query into its search box and submit it. Requires the Accessibility Service.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {
        'app': {'type': 'STRING'},
        'query': {'type': 'STRING'}
      },
      'required': ['app', 'query']
    }
  },
];

Future<String> _searchInApp(String app, String query) async {
  if (!await NativeBridge.a11yEnabled()) return 'accessibility_not_enabled';
  final opened = await NativeBridge.openApp(app);
  if (opened != 'ok') return opened;
  await Future.delayed(const Duration(milliseconds: 2500));
  var step = 'not_found';
  for (var i = 0; i < 3; i++) {
    step = await NativeBridge.findOrOpenSearch();
    if (step == 'editable_ready' || step == 'clicked_search') break;
    await Future.delayed(const Duration(milliseconds: 1200));
  }
  if (step == 'not_found') return 'no_search_field_found';
  if (step == 'clicked_search') await Future.delayed(const Duration(milliseconds: 1000));
  var t = await NativeBridge.typeText(query);
  if (t != 'ok') {
    await Future.delayed(const Duration(milliseconds: 1000));
    t = await NativeBridge.typeText(query);
  }
  if (t != 'ok') return t;
  await Future.delayed(const Duration(milliseconds: 500));
  final s = await NativeBridge.submit();
  return s == 'ok' ? 'ok' : 'typed_but_could_not_submit';
}

Future<String> _playYoutube(String q) async {
  if (!await NativeBridge.a11yEnabled()) return 'accessibility_not_enabled';
  final opened = await NativeBridge.openUrl(
      'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent(q)}',
      package: 'com.google.android.youtube');
  if (opened != 'ok') return opened;
  await Future.delayed(const Duration(milliseconds: 3500));
  var last = 'not_found';
  for (var i = 0; i < 4; i++) {
    last = await NativeBridge.clickFirstVideo(guess: i == 3);
    if (last == 'ok' || last == 'tapped_guess_unverified') return last;
    await Future.delayed(const Duration(milliseconds: 1500));
  }
  return last;
}

Future<Map<String, dynamic>> runTool(String name, Map<String, dynamic> args) async {
  String r;
  switch (name) {
    case 'open_app':
      r = await NativeBridge.openApp('${args['name']}');
      break;
    case 'web_search':
      r = await NativeBridge.openUrl(
          'https://www.google.com/search?q=${Uri.encodeQueryComponent('${args['query']}')}');
      break;
    case 'youtube_search':
      r = await NativeBridge.openUrl(
          'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent('${args['query']}')}');
      break;
    case 'send_message':
      if (!await NativeBridge.a11yEnabled()) return {'result': 'accessibility_not_enabled'};
      final app = '${args['app']}'.trim();
      final contact = '${args['contact'] ?? ''}'.trim();
      final message = '${args['message']}'.trim();
      if (message.isEmpty) return {'result': 'empty_message'};
      r = await NativeBridge.openApp(app);
      if (r != 'ok') break;
      await Future.delayed(const Duration(milliseconds: 2200));
      if (app.toLowerCase().contains('whatsapp')) {
        if (contact.isEmpty) return {'result': 'contact_required'};
        var search = await NativeBridge.findOrOpenSearch();
        if (search == 'clicked_search') await Future.delayed(const Duration(milliseconds: 500));
        if (search != 'editable_ready' && search != 'clicked_search') {
          return {'result': 'contact_search_not_found'};
        }
        final typedContact = await NativeBridge.typeText(contact);
        if (typedContact != 'ok') return {'result': 'contact_search_$typedContact'};
        await Future.delayed(const Duration(milliseconds: 1900));
        final selected = await NativeBridge.clickText(contact);
        if (selected != 'ok') return {'result': 'contact_not_found'};
        await Future.delayed(const Duration(milliseconds: 1000));
      }
      final typedMessage = await NativeBridge.typeText(message);
      if (typedMessage != 'ok') return {'result': 'message_type_$typedMessage'};
      await Future.delayed(const Duration(milliseconds: 350));
      r = await NativeBridge.clickSendButton();
      break;
    case 'search_in_app':
      r = await _searchInApp('${args['app']}', '${args['query']}');
      break;
    case 'play_youtube':
      r = await _playYoutube('${args['query']}');
      break;
    case 'click_text':
      r = await NativeBridge.clickText('${args['text']}');
      break;
    case 'type_text':
      r = await NativeBridge.typeText('${args['text']}');
      break;
    default:
      r = 'unknown_tool';
  }
  return {'result': r};
}
