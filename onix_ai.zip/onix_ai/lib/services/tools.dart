import 'native_bridge.dart';

/// Gemini function declarations + executor. Every result is the REAL outcome.
const toolDeclarations = [
  {
    'name': 'open_app',
    'description': 'Open an installed Android app by its name (e.g. Instagram, WhatsApp, Chrome).',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'name': {'type': 'STRING'}},
      'required': ['name']
    }
  },
  {
    'name': 'web_search',
    'description': 'Search Google in the browser.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'query': {'type': 'STRING'}},
      'required': ['query']
    }
  },
  {
    'name': 'youtube_search',
    'description': 'Search YouTube (songs, videos, artists). Opens results; user picks what to play.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'query': {'type': 'STRING'}},
      'required': ['query']
    }
  },
  {
    'name': 'whatsapp_compose',
    'description':
        'Open WhatsApp with a prefilled message. The user picks the contact and taps send themselves. Only call after the user has confirmed the message text.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'message': {'type': 'STRING'}},
      'required': ['message']
    }
  },
];

Future<Map<String, dynamic>> runTool(String name, Map<String, dynamic> args) async {
  String r;
  switch (name) {
    case 'open_app':
      r = await NativeBridge.openApp('${args['name']}');
      break;
    case 'web_search':
      r = await NativeBridge.openUrl(
          'https://www.google.com/search?q=${Uri.encodeQueryComponent('${args['query']}')}');
      break;
    case 'youtube_search':
      r = await NativeBridge.openUrl(
          'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent('${args['query']}')}');
      break;
    case 'whatsapp_compose':
      r = await NativeBridge.openUrl(
          'https://wa.me/?text=${Uri.encodeQueryComponent('${args['message']}')}');
      break;
    default:
      r = 'unknown_tool';
  }
  return {'result': r};
}
