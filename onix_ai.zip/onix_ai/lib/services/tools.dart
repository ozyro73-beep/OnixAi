import 'native_bridge.dart';

/// Gemini function declarations + executor. Every result is the REAL outcome.
const toolDeclarations = [
  {
    'name': 'open_app',
    'description': 'Open an installed Android app by its name (e.g. Instagram, WhatsApp, Chrome).',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'name': {'type': 'STRING'}},
      'required': ['name']
    }
  },
  {
    'name': 'web_search',
    'description': 'Search Google in the browser.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'query': {'type': 'STRING'}},
      'required': ['query']
    }
  },
  {
    'name': 'youtube_search',
    'description': 'Search YouTube (songs, videos, artists). Opens results; user picks what to play.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'query': {'type': 'STRING'}},
      'required': ['query']
    }
  },
  {
    'name': 'whatsapp_compose',
    'description':
        'Open WhatsApp with a prefilled message. The user picks the contact and taps send themselves. Only call after the user has confirmed the message text.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'message': {'type': 'STRING'}},
      'required': ['message']
    }
  },
  {
    'name': 'play_youtube',
    'description':
        'Search YouTube and automatically tap the first result so the song/video starts playing. Use this when the user says play/chalao a song or video. Requires the Accessibility Service.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'query': {'type': 'STRING'}},
      'required': ['query']
    }
  },
  {
    'name': 'click_text',
    'description': 'Tap a button or item on the current screen that shows this text. Requires the Accessibility Service.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'text': {'type': 'STRING'}},
      'required': ['text']
    }
  },
  {
    'name': 'type_text',
    'description': 'Type text into the currently focused text field (never password fields). Requires the Accessibility Service.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {'text': {'type': 'STRING'}},
      'required': ['text']
    }
  },
  {
    'name': 'search_in_app',
    'description':
        'Open ANY installed app (Chrome, Google, Instagram, Play Store, etc.), type the query into its search box and submit it. Requires the Accessibility Service.',
    'parameters': {
      'type': 'OBJECT',
      'properties': {
        'app': {'type': 'STRING'},
        'query': {'type': 'STRING'}
      },
      'required': ['app', 'query']
    }
  },
];

Future<String> _searchInApp(String app, String query) async {
  if (!await NativeBridge.a11yEnabled()) return 'accessibility_not_enabled';
  final opened = await NativeBridge.openApp(app);
  if (opened != 'ok') return opened;
  await Future.delayed(const Duration(milliseconds: 2500));
  var step = 'not_found';
  for (var i = 0; i < 3; i++) {
    step = await NativeBridge.findOrOpenSearch();
    if (step == 'editable_ready' || step == 'clicked_search') break;
    await Future.delayed(const Duration(milliseconds: 1200));
  }
  if (step == 'not_found') return 'no_search_field_found';
  if (step == 'clicked_search') await Future.delayed(const Duration(milliseconds: 1000));
  var t = await NativeBridge.typeText(query);
  if (t != 'ok') {
    await Future.delayed(const Duration(milliseconds: 1000));
    t = await NativeBridge.typeText(query);
  }
  if (t != 'ok') return t;
  await Future.delayed(const Duration(milliseconds: 500));
  final s = await NativeBridge.submit();
  return s == 'ok' ? 'ok' : 'typed_but_could_not_submit';
}

Future<String> _playYoutube(String q) async {
  if (!await NativeBridge.a11yEnabled()) return 'accessibility_not_enabled';
  final opened = await NativeBridge.openUrl(
      'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent(q)}',
      package: 'com.google.android.youtube');
  if (opened != 'ok') return opened;
  await Future.delayed(const Duration(milliseconds: 3500));
  var last = 'not_found';
  for (var i = 0; i < 4; i++) {
    last = await NativeBridge.clickFirstVideo(guess: i == 3);
    if (last == 'ok' || last == 'tapped_guess_unverified') return last;
    await Future.delayed(const Duration(milliseconds: 1500));
  }
  return last;
}

Future<Map<String, dynamic>> runTool(String name, Map<String, dynamic> args) async {
  String r;
  switch (name) {
    case 'open_app':
      r = await NativeBridge.openApp('${args['name']}');
      break;
    case 'web_search':
      r = await NativeBridge.openUrl(
          'https://www.google.com/search?q=${Uri.encodeQueryComponent('${args['query']}')}');
      break;
    case 'youtube_search':
      r = await NativeBridge.openUrl(
          'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent('${args['query']}')}');
      break;
    case 'whatsapp_compose':
      r = await NativeBridge.openUrl(
          'https://wa.me/?text=${Uri.encodeQueryComponent('${args['message']}')}');
      break;
    case 'search_in_app':
      r = await _searchInApp('${args['app']}', '${args['query']}');
      break;
    case 'play_youtube':
      r = await _playYoutube('${args['query']}');
      break;
    case 'click_text':
      r = await NativeBridge.clickText('${args['text']}');
      break;
    case 'type_text':
      r = await NativeBridge.typeText('${args['text']}');
      break;
    default:
      r = 'unknown_tool';
  }
  return {'result': r};
}
