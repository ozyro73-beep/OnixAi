import 'package:flutter/services.dart';

/// Thin wrapper over the Kotlin MethodChannel.
class NativeBridge {
  static const _ch = MethodChannel('onix/native');

  static Future<String> openApp(String name) async =>
      (await _ch.invokeMethod<String>('openApp', {'name': name})) ?? 'error';

  static Future<String> openUrl(String url) async =>
      (await _ch.invokeMethod<String>('openUrl', {'url': url})) ?? 'error';
}
