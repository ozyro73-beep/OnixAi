import 'package:flutter/services.dart';

/// Thin wrapper over the Kotlin MethodChannel.
class NativeBridge {
  static const _ch = MethodChannel('onix/native');
  static void setStopHandler(Future<void> Function() handler) {
    const MethodChannel('onix/control').setMethodCallHandler((call) async {
      if (call.method == 'stopOnix') await handler();
    });
  }

  static Future<String> openApp(String name) async =>
      (await _ch.invokeMethod<String>('openApp', {'name': name})) ?? 'error';

  static Future<String> openUrl(String url, {String? package}) async =>
      (await _ch.invokeMethod<String>('openUrl', {'url': url, 'package': package})) ?? 'error';

  static Future<bool> a11yEnabled() async => (await _ch.invokeMethod<bool>('a11yEnabled')) ?? false;
  static Future<void> openA11ySettings() => _ch.invokeMethod('openA11ySettings');
  static Future<String> clickText(String t) async =>
      (await _ch.invokeMethod<String>('clickText', {'text': t})) ?? 'error';
  static Future<String> clickFirstVideo({bool guess = false}) async =>
      (await _ch.invokeMethod<String>('clickFirstVideo', {'guess': guess})) ?? 'error';
  static Future<String> typeText(String t) async =>
      (await _ch.invokeMethod<String>('typeText', {'text': t})) ?? 'error';

  static Future<String> findOrOpenSearch() async =>
      (await _ch.invokeMethod<String>('findOrOpenSearch')) ?? 'error';
  static Future<String> submit() async => (await _ch.invokeMethod<String>('submit')) ?? 'error';
  static Future<String> clickSendButton() async => (await _ch.invokeMethod<String>('clickSendButton')) ?? 'error';
  static Future<void> playBeep() async { try { await _ch.invokeMethod('playBeep'); } catch (_) {} }
  static Future<void> muteBeep() => _ch.invokeMethod('muteBeep');
  static Future<void> unmuteBeep() => _ch.invokeMethod('unmuteBeep');
  static Future<bool> consumeStopRequest() async => (await _ch.invokeMethod<bool>('consumeStopRequest')) ?? false;
  static Future<String?> startKeepAlive() => _ch.invokeMethod<String>('startKeepAlive');
  static Future<void> stopKeepAlive() => _ch.invokeMethod('stopKeepAlive');
  static Future<bool> overlayPermissionGranted() async => (await _ch.invokeMethod<bool>('overlayPermissionGranted')) ?? false;
  static Future<void> requestOverlayPermission() => _ch.invokeMethod('requestOverlayPermission');
}
