import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final FlutterTts tts = FlutterTts();
  final SpeechToText stt = SpeechToText();
  bool _sttReady = false;
  void Function()? onEnded;

  VoiceService() {
    tts.awaitSpeakCompletion(true);
  }

  Future<List<Map<String, String>>> voices() async {
    final v = await tts.getVoices as List?;
    return (v ?? [])
        .map((e) => Map<String, String>.from((e as Map).map((k, v) => MapEntry('$k', '$v'))))
        .toList();
  }

  Future<void> configure({required double rate, required double pitch, required String locale, String? voiceName}) async {
    await tts.setSpeechRate(rate);
    await tts.setPitch(pitch);
    await tts.setLanguage(locale);
    if (voiceName != null) {
      final all = await voices();
      final m = all.where((v) => v['name'] == voiceName);
      if (m.isNotEmpty) await tts.setVoice({'name': m.first['name']!, 'locale': m.first['locale']!});
    }
  }

  /// Completes when speaking is finished (or stopped).
  static final _emoji = RegExp(
      r'[\u{1F000}-\u{1FAFF}\u{2300}-\u{23FF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE00}-\u{FE0F}\u{200D}\u{20E3}]',
      unicode: true);

  /// Removes emojis and markdown symbols so TTS doesn't read their names.
  String _clean(String t) =>
      t.replaceAll(_emoji, '').replaceAll(RegExp(r'[*_#`~>]'), '').replaceAll(RegExp(r'\s+'), ' ').trim();

  Future<void> speak(String text) async {
    final clean = _clean(text);
    if (clean.isEmpty) return;
    await stopListening();
    await tts.speak(clean);
  }

  Future<void> stopSpeaking() => tts.stop();

  Future<bool> listen(String locale, void Function(String text, bool done) onResult) async {
    _sttReady = _sttReady ||
        await stt.initialize(
          onStatus: (s) {
            if (s == 'done' || s == 'notListening') onEnded?.call();
          },
          onError: (_) => onEnded?.call(),
        );
    if (!_sttReady) return false;
    await stt.listen(
      localeId: locale,
      listenFor: const Duration(seconds: 60),
      pauseFor: const Duration(seconds: 5),
      onResult: (r) => onResult(r.recognizedWords, r.finalResult),
    );
    return true;
  }

  Future<void> stopListening() async {
    if (stt.isListening) await stt.stop();
  }
}
