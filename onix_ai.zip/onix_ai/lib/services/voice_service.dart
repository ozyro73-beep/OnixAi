import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final FlutterTts tts = FlutterTts();
  final SpeechToText stt = SpeechToText();
  final AudioPlayer _audio = AudioPlayer();
  bool _sttReady = false;
  bool _starting = false;
  void Function()? onEnded;

  VoiceService() { tts.awaitSpeakCompletion(true); }

  Future<List<Map<String, String>>> voices() async {
    final v = await tts.getVoices as List?;
    return (v ?? []).map((e) => Map<String, String>.from((e as Map).map((k, v) => MapEntry('$k', '$v')))).toList();
  }

  Future<void> configure({required double rate, required double pitch, required String locale, String? voiceName}) async {
    await tts.setSpeechRate(rate);
    await tts.setPitch(pitch);
    await tts.setLanguage(locale);
    if (voiceName != null) {
      final all = await voices();
      final m = all.where((v) => v['name'] == voiceName);
      if (m.isNotEmpty) await tts.setVoice({'name': m.first['name']!, 'locale': m.first['locale']!});
    }
  }

  static final _emoji = RegExp(r'[\u{1F000}-\u{1FAFF}\u{2300}-\u{23FF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE00}-\u{FE0F}\u{200D}\u{20E3}]', unicode: true);
  String _clean(String t) => t.replaceAll(_emoji, '').replaceAll(RegExp(r'[*_#`~>]'), '').replaceAll(RegExp(r'\s+'), ' ').trim();

  Future<void> speak(String text) async {
    final clean = _clean(text);
    if (clean.isEmpty) return;
    await stopListening();
    await _audio.stop();
    await tts.speak(clean);
  }

  Future<void> speakBytes(List<int> bytes) async {
    await stopListening();
    await tts.stop();
    await _audio.stop();
    final completed = _audio.onPlayerComplete.first;
    await _audio.play(BytesSource(Uint8List.fromList(bytes)));
    await completed;
  }

  Future<void> stopSpeaking() async { await tts.stop(); await _audio.stop(); }

  Future<bool> listen(String locale, void Function(String text, bool done) onResult) async {
    if (_starting || stt.isListening) return true;
    _starting = true;
    try {
      _sttReady = _sttReady || await stt.initialize(
        onStatus: (s) { if (s == 'done' || s == 'notListening') onEnded?.call(); },
        onError: (_) => onEnded?.call(),
      );
      if (!_sttReady) return false;
      await stt.listen(localeId: locale, listenFor: const Duration(seconds: 45), pauseFor: const Duration(seconds: 3),
        onResult: (r) => onResult(r.recognizedWords, r.finalResult));
      return true;
    } finally { _starting = false; }
  }

  Future<void> stopListening() async { if (stt.isListening) await stt.stop(); }
}
