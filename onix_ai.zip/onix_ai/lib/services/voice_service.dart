import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final SpeechToText stt = SpeechToText();
  final AudioPlayer _audio = AudioPlayer();
  bool _sttReady = false;
  bool _starting = false;
  void Function()? onEnded;

  VoiceService();

  /// ONIX assistant speech is ElevenLabs-only. No Android/Google TTS fallback.
  Future<void> speak(String text) async {
    throw Exception('ElevenLabs voice is required. Add your Voice ID and API key in Settings.');
  }


  Future<void> speakElevenLabs({required String apiKey, required String voiceId, required String text}) async {
    if (apiKey.trim().isEmpty) throw Exception('ElevenLabs API key missing.');
    if (voiceId.trim().isEmpty) throw Exception('ElevenLabs Voice ID missing.');
    final response = await http.post(
      Uri.parse('https://api.elevenlabs.io/v1/text-to-speech/${Uri.encodeComponent(voiceId.trim())}?output_format=mp3_44100_128'),
      headers: {'xi-api-key': apiKey.trim(), 'Content-Type': 'application/json', 'Accept': 'audio/mpeg'},
      body: jsonEncode({'text': text, 'model_id': 'eleven_multilingual_v2', 'voice_settings': {'stability': 0.45, 'similarity_boost': 0.8}}),
    ).timeout(const Duration(seconds: 60));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      String detail = 'HTTP ${response.statusCode}';
      try { detail = (jsonDecode(utf8.decode(response.bodyBytes))['detail']?['message'] ?? jsonDecode(utf8.decode(response.bodyBytes))['detail'] ?? detail).toString(); } catch (_) {}
      throw Exception('ElevenLabs: $detail');
    }
    await speakBytes(response.bodyBytes);
  }

  Future<void> speakBytes(List<int> bytes) async {
    await stopListening();
    await _audio.stop();
    final completed = _audio.onPlayerComplete.first;
    await _audio.play(BytesSource(Uint8List.fromList(bytes)));
    await completed;
  }

  Future<void> stopSpeaking() async { await _audio.stop(); }

  Future<bool> listen(String locale, void Function(String text, bool done) onResult) async {
    if (_starting || stt.isListening) return true;
    _starting = true;
    try {
      _sttReady = _sttReady || await stt.initialize(
        onStatus: (s) { if (s == 'done' || s == 'notListening') onEnded?.call(); },
        onError: (_) => onEnded?.call(),
      );
      if (!_sttReady) return false;
      await stt.listen(localeId: locale, listenFor: const Duration(seconds: 45), pauseFor: const Duration(seconds: 2),
        onResult: (r) => onResult(r.recognizedWords, r.finalResult));
      return true;
    } finally { _starting = false; }
  }

  Future<void> stopListening() async { if (stt.isListening) await stt.stop(); }
}
