import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final FlutterTts tts = FlutterTts();
  final SpeechToText stt = SpeechToText();
  bool _sttReady = false;

  Future<List<Map<String, String>>> voices() async {
    final v = await tts.getVoices as List?;
    return (v ?? [])
        .map((e) => Map<String, String>.from(
            (e as Map).map((k, v) => MapEntry('$k', '$v'))))
        .toList();
  }

  Future<void> configure({required double rate, required double pitch, required String locale, String? voiceName}) async {
    await tts.setSpeechRate(rate);
    await tts.setPitch(pitch);
    await tts.setLanguage(locale);
    if (voiceName != null) {
      final all = await voices();
      final m = all.where((v) => v['name'] == voiceName);
      if (m.isNotEmpty) await tts.setVoice({'name': m.first['name']!, 'locale': m.first['locale']!});
    }
  }

  Future<void> speak(String text) async {
    await stopListening();
    await tts.speak(text);
  }

  Future<void> stopSpeaking() => tts.stop();

  Future<bool> listen(String locale, void Function(String text, bool done) onResult) async {
    await stopSpeaking(); // user interrupts ONIX
    _sttReady = _sttReady || await stt.initialize();
    if (!_sttReady) return false;
    await stt.listen(
      localeId: locale,
      onResult: (r) => onResult(r.recognizedWords, r.finalResult),
    );
    return true;
  }

  Future<void> stopListening() async {
    if (stt.isListening) await stt.stop();
  }
}
