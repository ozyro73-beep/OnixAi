import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'gemini_service.dart' show GeminiException;
import 'tools.dart';

/// Groq (OpenAI-compatible) chat service with tool calling.
class GroqService {
  static const _base = 'https://api.groq.com/openai/v1';

  dynamic _lower(dynamic v) {
    if (v is Map) {
      return v.map((k, x) => MapEntry(k, k == 'type' && x is String ? x.toLowerCase() : _lower(x)));
    }
    if (v is List) return v.map(_lower).toList();
    return v;
  }

  List<Map<String, dynamic>> get _tools => toolDeclarations
      .map((t) => {'type': 'function', 'function': _lower(t)})
      .toList()
      .cast<Map<String, dynamic>>();

  Future<String> chat({
    required String apiKey,
    required String model,
    required String system,
    required List<Map<String, dynamic>> history,
  }) async {
    if (apiKey.isEmpty) throw GeminiException('Add your Groq API key in Settings.');
    for (var step = 0; step < 5; step++) {
      final body = {
        'model': model,
        'messages': [
          {'role': 'system', 'content': system},
          ...history
        ],
        'tools': _tools,
        'tool_choice': 'auto',
        if (model.contains('gpt-oss')) 'reasoning_effort': 'low',
      };
      http.Response res;
      try {
        res = await http
            .post(Uri.parse('$_base/chat/completions'),
                headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $apiKey'},
                body: jsonEncode(body))
            .timeout(const Duration(seconds: 30));
      } on TimeoutException {
        throw GeminiException('Groq timed out after 30s (model: $model).');
      } catch (e) {
        throw GeminiException('Network error: $e');
      }
      final data = jsonDecode(utf8.decode(res.bodyBytes));
      if (res.statusCode != 200) {
        throw GeminiException(data['error']?['message'] ?? 'HTTP ${res.statusCode}');
      }
      final msg = data['choices'][0]['message'];
      final calls = (msg['tool_calls'] as List?) ?? [];
      if (calls.isEmpty) {
        final text = (msg['content'] ?? '').toString().trim();
        history.add({'role': 'assistant', 'content': text});
        return text;
      }
      history.add({'role': 'assistant', 'content': msg['content'] ?? '', 'tool_calls': calls});
      for (final c in calls) {
        final fn = c['function'];
        Map<String, dynamic> args = {};
        try {
          args = Map<String, dynamic>.from(jsonDecode(fn['arguments'] ?? '{}'));
        } catch (_) {}
        final out = await runTool(fn['name'], args);
        history.add({'role': 'tool', 'tool_call_id': c['id'], 'content': jsonEncode(out)});
      }
    }
    return 'I got stuck in a loop of actions, so I stopped.';
  }

  Future<String?> testConnection(String apiKey) async {
    try {
      final res = await http
          .get(Uri.parse('$_base/models'), headers: {'Authorization': 'Bearer $apiKey'})
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return null;
      return jsonDecode(res.body)['error']?['message'] ?? 'HTTP ${res.statusCode}';
    } catch (e) {
      return '$e';
    }
  }
}
