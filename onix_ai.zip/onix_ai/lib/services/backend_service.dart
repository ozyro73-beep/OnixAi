import 'dart:convert';
import 'package:http/http.dart' as http;

class BackendService {
  Future<String?> test(String baseUrl) async {
    final base = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) return 'Enter backend URL';
    try {
      final r = await http.get(Uri.parse('$base/health')).timeout(const Duration(seconds: 15));
      return r.statusCode == 200 ? null : 'HTTP ${r.statusCode}';
    } catch (e) { return '$e'; }
  }

  Future<String> chat({required String baseUrl, required String token, required String userId, required String message, required String system}) async {
    final base = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) throw Exception('Set your ONIX backend URL in Settings.');
    final response = await http.post(
      Uri.parse('$base/v1/chat'),
      headers: {'Content-Type': 'application/json', if (token.isNotEmpty) 'Authorization': 'Bearer $token'},
      body: jsonEncode({'user_id': userId, 'message': message, 'system': system}),
    ).timeout(const Duration(seconds: 90));
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['detail'] ?? data['error'] ?? 'Backend HTTP ${response.statusCode}');
    }
    final reply = (data['reply'] ?? '').toString().trim();
    if (reply.isEmpty) throw Exception('Cloud AI returned an empty response.');
    return reply;
  }

  Future<void> clearMemory({required String baseUrl, required String token, required String userId}) async {
    final base = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) return;
    final r = await http.delete(Uri.parse('$base/v1/memory/${Uri.encodeComponent(userId)}'), headers: {'Authorization': 'Bearer $token'}).timeout(const Duration(seconds: 20));
    if (r.statusCode < 200 || r.statusCode >= 300) throw Exception('Memory clear failed: HTTP ${r.statusCode}');
  }

  Future<List<int>> speak({required String baseUrl, required String token, required String text, required String voiceId}) async {
    final base = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) throw Exception('Set your ONIX backend URL in Settings.');
    final response = await http.post(Uri.parse('$base/v1/tts'),
      headers: {'Content-Type': 'application/json', if (token.isNotEmpty) 'Authorization': 'Bearer $token'},
      body: jsonEncode({'text': text, 'voice_id': voiceId}),
    ).timeout(const Duration(seconds: 60));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      try { throw Exception(jsonDecode(response.body)['detail'] ?? 'TTS HTTP ${response.statusCode}'); }
      on FormatException { throw Exception('TTS HTTP ${response.statusCode}'); }
    }
    return response.bodyBytes;
  }
}
