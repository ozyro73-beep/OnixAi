import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'tools.dart';

class GeminiException implements Exception {
  final String message;
  GeminiException(this.message);
  @override
  String toString() => message;
}

/// Single entry point for all AI requests (Gemini REST API).
class GeminiService {
  static const _base = 'https://generativelanguage.googleapis.com/v1beta';

  Future<http.Response> _post(String apiKey, String model, Map body) async {
    final uri = Uri.parse('$_base/models/$model:generateContent');
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final res = await http
            .post(uri,
                headers: {'Content-Type': 'application/json', 'x-goog-api-key': apiKey},
                body: jsonEncode(body))
            .timeout(const Duration(seconds: 40));
        if ((res.statusCode == 429 || res.statusCode >= 500) && attempt < 2) {
          await Future.delayed(Duration(seconds: 1 << attempt));
          continue;
        }
        return res;
      } on TimeoutException {
        if (attempt == 2) throw GeminiException('Request timed out.');
      } on Exception catch (e) {
        if (attempt == 2) throw GeminiException('Network error: $e');
      }
    }
    throw GeminiException('Request failed.');
  }

  /// Multi-step loop: model -> tool call -> tool result -> model ...
  Future<String> chat({
    required String apiKey,
    required String model,
    required String system,
    required List<Map<String, dynamic>> history, // mutated with new turns
  }) async {
    if (apiKey.isEmpty) throw GeminiException('Add your Gemini API key in Settings.');
    for (var step = 0; step < 5; step++) {
      final res = await _post(apiKey, model, {
        'systemInstruction': {'parts': [{'text': system}]},
        'contents': history,
        'tools': [{'functionDeclarations': toolDeclarations}],
      });
      final data = jsonDecode(res.body);
      if (res.statusCode != 200) {
        throw GeminiException(data['error']?['message'] ?? 'HTTP ${res.statusCode}');
      }
      final content = data['candidates']?[0]?['content'];
      if (content == null) throw GeminiException('Empty response (possibly blocked).');
      final parts = (content['parts'] as List?) ?? [];
      final calls = parts.where((p) => p['functionCall'] != null).toList();
      history.add({'role': 'model', 'parts': parts});
      if (calls.isEmpty) {
        return parts.map((p) => p['text'] ?? '').join().trim();
      }
      final responses = <Map<String, dynamic>>[];
      for (final c in calls) {
        final fc = c['functionCall'];
        final out = await runTool(fc['name'], Map<String, dynamic>.from(fc['args'] ?? {}));
        responses.add({'functionResponse': {'name': fc['name'], 'response': out}});
      }
      history.add({'role': 'user', 'parts': responses});
    }
    return 'I got stuck in a loop of actions, so I stopped.';
  }

  /// Returns null on success, or an error message.
  Future<String?> testConnection(String apiKey) async {
    try {
      final res = await http
          .get(Uri.parse('$_base/models?pageSize=1'), headers: {'x-goog-api-key': apiKey})
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return null;
      return jsonDecode(res.body)['error']?['message'] ?? 'HTTP ${res.statusCode}';
    } catch (e) {
      return '$e';
    }
  }
}
