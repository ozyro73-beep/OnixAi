import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/gemini_service.dart';
import '../services/voice_service.dart';

class ChatMsg {
  final String text;
  final bool fromUser;
  final bool isError;
  ChatMsg(this.text, this.fromUser, {this.isError = false});
}

enum Persona { friendly, playful, professional }

class AppState extends ChangeNotifier {
  final _secure = const FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));
  late SharedPreferences _prefs;
  final gemini = GeminiService();
  final voice = VoiceService();

  String apiKey = '';
  String model = 'gemini-2.5-flash';
  double rate = 0.5, pitch = 1.1;
  String locale = 'en-IN';
  String? voiceName;
  Persona persona = Persona.friendly;
  bool speakReplies = true;

  final messages = <ChatMsg>[];
  final _history = <Map<String, dynamic>>[];
  bool busy = false, listening = false, paused = false;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    apiKey = await _secure.read(key: 'gemini_key') ?? '';
    model = _prefs.getString('model') ?? model;
    rate = _prefs.getDouble('rate') ?? rate;
    pitch = _prefs.getDouble('pitch') ?? pitch;
    locale = _prefs.getString('locale') ?? locale;
    voiceName = _prefs.getString('voice');
    persona = Persona.values[_prefs.getInt('persona') ?? 0];
    speakReplies = _prefs.getBool('speak') ?? true;
    await _applyVoice();
  }

  Future<void> _applyVoice() =>
      voice.configure(rate: rate, pitch: pitch, locale: locale, voiceName: voiceName);

  Future<void> saveSettings({String? key, String? mdl, double? r, double? p, String? loc, String? vName, Persona? per, bool? speak}) async {
    if (key != null) { apiKey = key.trim(); await _secure.write(key: 'gemini_key', value: apiKey); }
    if (mdl != null) { model = mdl; await _prefs.setString('model', mdl); }
    if (r != null) { rate = r; await _prefs.setDouble('rate', r); }
    if (p != null) { pitch = p; await _prefs.setDouble('pitch', p); }
    if (loc != null) { locale = loc; await _prefs.setString('locale', loc); }
    if (vName != null) { voiceName = vName; await _prefs.setString('voice', vName); }
    if (per != null) { persona = per; await _prefs.setInt('persona', per.index); }
    if (speak != null) { speakReplies = speak; await _prefs.setBool('speak', speak); }
    await _applyVoice();
    notifyListeners();
  }

  String get _tone => const {
        Persona.friendly: 'warm, caring and friendly',
        Persona.playful: 'playful, witty and kindly teasing',
        Persona.professional: 'concise and professional',
      }[persona]!;

  String get _system => '''
You are ONIX, a female AI best friend and personal assistant on the user's Android phone.
Understand Hindi, English and Hinglish; reply in the language the user writes in.
Tone: $_tone.
Keep replies short and natural since they may be spoken aloud. Avoid markdown symbols.
You can call tools to open apps, search Google/YouTube, and prepare WhatsApp messages.
Rules: NEVER claim an action succeeded unless the tool result is "ok"; if a tool returns an error or not_found, say so honestly.
Before preparing a message to someone, show the exact text and ask the user to confirm; only then call whatsapp_compose.
Never ask for or handle passwords, OTPs or payment details.''';

  Future<void> send(String text) async {
    text = text.trim();
    if (text.isEmpty || busy) return;
    messages.add(ChatMsg(text, true));
    final low = text.toLowerCase();
    if (RegExp(r'^(onix[, ]+)?(stop|pause)').hasMatch(low)) {
      await stopAll();
      paused = true;
      messages.add(ChatMsg("Okay, I've stopped. Tap resume whenever you want me back.", false));
      notifyListeners();
      return;
    }
    if (RegExp(r'^onix[, ]+(start|resume)').hasMatch(low)) {
      paused = false;
      messages.add(ChatMsg("I'm back! Kya karna hai?", false));
      notifyListeners();
      return;
    }
    if (paused) {
      messages.add(ChatMsg("I'm paused. Tap resume to continue.", false));
      notifyListeners();
      return;
    }
    busy = true;
    notifyListeners();
    _history.add({'role': 'user', 'parts': [{'text': text}]});
    final mark = _history.length - 1;
    try {
      final reply = await gemini.chat(apiKey: apiKey, model: model, system: _system, history: _history);
      messages.add(ChatMsg(reply, false));
      if (speakReplies && reply.isNotEmpty) voice.speak(reply);
    } catch (e) {
      _history.removeRange(mark, _history.length);
      messages.add(ChatMsg('$e', false, isError: true));
    }
    busy = false;
    notifyListeners();
  }

  Future<void> toggleMic() async {
    if (listening) {
      await voice.stopListening();
      listening = false;
      notifyListeners();
      return;
    }
    final ok = await voice.listen(locale, (t, done) {
      if (done) {
        listening = false;
        notifyListeners();
        send(t);
      }
    });
    listening = ok;
    if (!ok) messages.add(ChatMsg('Speech recognition unavailable or microphone permission denied.', false, isError: true));
    notifyListeners();
  }

  Future<void> stopAll() async {
    await voice.stopSpeaking();
    await voice.stopListening();
    listening = false;
    notifyListeners();
  }

  void pause() { stopAll(); paused = true; notifyListeners(); }
  void resume() { paused = false; notifyListeners(); }
  void clearChat() { messages.clear(); _history.clear(); notifyListeners(); }
}
