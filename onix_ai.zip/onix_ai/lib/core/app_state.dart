import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/gemini_service.dart';
import '../services/groq_service.dart';
import '../services/native_bridge.dart';
import '../services/voice_service.dart';

class ChatMsg {
  final String text;
  final bool fromUser;
  final bool isError;
  ChatMsg(this.text, this.fromUser, {this.isError = false});
}

enum Persona { friendly, playful, professional }

class AppState extends ChangeNotifier {
  final _secure = const FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));
  late SharedPreferences _prefs;
  final gemini = GeminiService();
  final groq = GroqService();
  String provider = 'groq';
  String groqKey = '';
  String groqModel = 'openai/gpt-oss-20b';
  final _groqHistory = <Map<String, dynamic>>[];
  bool autoFallback = true;
  double fallbackSecs = 2;
  final voice = VoiceService();

  String apiKey = '';
  String model = 'gemini-2.5-flash';
  double rate = 0.5, pitch = 1.1;
  String locale = 'en-IN';
  String? voiceName;
  Persona persona = Persona.friendly;
  bool speakReplies = true;

  final messages = <ChatMsg>[];
  final _history = <Map<String, dynamic>>[];
  bool busy = false, listening = false, paused = false, continuous = false, speaking = false;
  Timer? _listenTimer;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    apiKey = await _secure.read(key: 'gemini_key') ?? '';
    model = _prefs.getString('model') ?? model;
    provider = _prefs.getString('provider') ?? provider;
    groqKey = await _secure.read(key: 'groq_key') ?? '';
    groqModel = _prefs.getString('groq_model') ?? groqModel;
    autoFallback = _prefs.getBool('auto_fb') ?? true;
    fallbackSecs = _prefs.getDouble('fb_secs') ?? 2;
    rate = _prefs.getDouble('rate') ?? rate;
    pitch = _prefs.getDouble('pitch') ?? pitch;
    locale = _prefs.getString('locale') ?? locale;
    voiceName = _prefs.getString('voice');
    persona = Persona.values[_prefs.getInt('persona') ?? 0];
    speakReplies = _prefs.getBool('speak') ?? true;
    await _applyVoice();
  }

  Future<void> _applyVoice() =>
      voice.configure(rate: rate, pitch: pitch, locale: locale, voiceName: voiceName);

  Future<void> saveSettings({String? key, String? mdl, double? r, double? p, String? loc, String? vName, Persona? per, bool? speak, String? prov, String? gKey, String? gModel, bool? autoFb, double? fbSecs}) async {
    if (autoFb != null) { autoFallback = autoFb; await _prefs.setBool('auto_fb', autoFb); }
    if (fbSecs != null) { fallbackSecs = fbSecs; await _prefs.setDouble('fb_secs', fbSecs); }
    if (prov != null) { provider = prov; await _prefs.setString('provider', prov); }
    if (gKey != null) { groqKey = gKey.trim(); await _secure.write(key: 'groq_key', value: groqKey); }
    if (gModel != null) { groqModel = gModel.trim(); await _prefs.setString('groq_model', groqModel); }
    if (key != null) { apiKey = key.trim(); await _secure.write(key: 'gemini_key', value: apiKey); }
    if (mdl != null) { model = mdl; await _prefs.setString('model', mdl); }
    if (r != null) { rate = r; await _prefs.setDouble('rate', r); }
    if (p != null) { pitch = p; await _prefs.setDouble('pitch', p); }
    if (loc != null) { locale = loc; await _prefs.setString('locale', loc); }
    if (vName != null) { voiceName = vName; await _prefs.setString('voice', vName); }
    if (per != null) { persona = per; await _prefs.setInt('persona', per.index); }
    if (speak != null) { speakReplies = speak; await _prefs.setBool('speak', speak); }
    await _applyVoice();
    notifyListeners();
  }

  String get _tone => const {
        Persona.friendly: 'warm, caring and friendly',
        Persona.playful: 'playful, witty and kindly teasing',
        Persona.professional: 'concise and professional',
      }[persona]!;

  String get _system => '''
You are ONIX, a female AI best friend and personal assistant on the user's Android phone.
Understand Hindi, English and Hinglish; reply in the language the user writes in.
Tone: $_tone.
Keep replies short and natural since they may be spoken aloud. Never use emojis or markdown symbols.
You can call tools to open apps, search Google/YouTube, and prepare WhatsApp messages.
To search inside ANY app (Chrome, Google, Instagram, Play Store...) use search_in_app. If the user asks to PLAY a song/video, use play_youtube. If a tool returns accessibility_not_enabled, tell them to turn on ONIX AI in Android Accessibility settings (Settings screen has a button). If it returns tapped_guess_unverified, say you tapped but are not sure it worked.
Rules: NEVER claim an action succeeded unless the tool result is "ok"; if a tool returns an error or not_found, say so honestly.
Before preparing a message to someone, show the exact text and ask the user to confirm; only then call whatsapp_compose.
Never ask for or handle passwords, OTPs or payment details.''';

  Future<void> send(String text) async {
    text = text.trim();
    if (text.isEmpty || busy) return;
    messages.add(ChatMsg(text, true));
    final low = text.toLowerCase();
    if (RegExp(r'^(onix[, ]+)?(stop|pause)').hasMatch(low)) {
      await stopAll();
      paused = true;
      messages.add(ChatMsg("Okay, I've stopped. Tap resume whenever you want me back.", false));
      notifyListeners();
      return;
    }
    if (RegExp(r'^onix[, ]+(start|resume)').hasMatch(low)) {
      paused = false;
      messages.add(ChatMsg("I'm back! Kya karna hai?", false));
      notifyListeners();
      return;
    }
    if (paused) {
      messages.add(ChatMsg("I'm paused. Tap resume to continue.", false));
      notifyListeners();
      return;
    }
    busy = true;
    notifyListeners();
    final useGroq = provider == 'groq';
    final hist = useGroq ? _groqHistory : _history;
    hist.add(useGroq
        ? {'role': 'user', 'content': text}
        : {'role': 'user', 'parts': [{'text': text}]});
    final mark = hist.length - 1;
    var fellBack = false;
    var gMark = 0;
    try {
      String reply;
      if (useGroq) {
        reply = await groq.chat(apiKey: groqKey, model: groqModel, system: _system, history: _groqHistory);
      } else {
        try {
          reply = await gemini.chat(
            apiKey: apiKey, model: model, system: _system, history: _history,
            firstTimeout: (autoFallback && groqKey.isNotEmpty)
                ? Duration(milliseconds: (fallbackSecs * 1000).round())
                : null,
          );
        } on GeminiTimeout {
          fellBack = true;
          _history.removeRange(mark, _history.length);
          gMark = _groqHistory.length;
          _groqHistory.add({'role': 'user', 'content': text});
          reply = await groq.chat(apiKey: groqKey, model: groqModel, system: _system, history: _groqHistory);
        }
      }
      messages.add(ChatMsg(reply, false));
      if (speakReplies && reply.isNotEmpty) {
        speaking = true;
        notifyListeners();
        await voice.speak(reply);
        speaking = false;
      }
    } catch (e) {
      if (fellBack) {
        if (gMark <= _groqHistory.length) _groqHistory.removeRange(gMark, _groqHistory.length);
      } else if (mark <= hist.length) {
        hist.removeRange(mark, hist.length);
      }
      messages.add(ChatMsg('$e', false, isError: true));
    }
    busy = false;
    notifyListeners();
    if (continuous) _scheduleListen();
  }

  Future<void> toggleMic() => continuous ? stopContinuous() : startContinuous();

  void _onSpeech(String t, bool done) {
    if (done && t.trim().length > 1) send(t);
  }

  void _scheduleListen([int ms = 700]) {
    _listenTimer?.cancel();
    _listenTimer = Timer(Duration(milliseconds: ms), _listenOnce);
  }

  Future<void> _listenOnce() async {
    if (!continuous || busy || speaking || paused) return;
    await voice.listen(locale, _onSpeech);
  }

  /// Always-on mic: keeps listening until stopped.
  Future<void> startContinuous() async {
    continuous = true;
    listening = true;
    paused = false;
    notifyListeners();
    await NativeBridge.muteBeep();
    voice.onEnded = () {
      if (continuous && !busy && !speaking && !paused) _scheduleListen();
    };
    final ok = await voice.listen(locale, _onSpeech);
    if (!ok) {
      messages.add(ChatMsg('Microphone/speech recognition unavailable or permission denied.', false, isError: true));
      await stopContinuous();
      return;
    }
    await NativeBridge.startKeepAlive();
  }

  Future<void> stopContinuous() async {
    continuous = false;
    listening = false;
    _listenTimer?.cancel();
    await voice.stopListening();
    await NativeBridge.unmuteBeep();
    await NativeBridge.stopKeepAlive();
    notifyListeners();
  }

  Future<void> stopAll() async {
    await voice.stopSpeaking();
    await stopContinuous();
  }

  void pause() { stopAll(); paused = true; notifyListeners(); }
  void resume() { paused = false; notifyListeners(); }
  void clearChat() { messages.clear(); _history.clear(); _groqHistory.clear(); notifyListeners(); }
}
