import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/gemini_service.dart';
import '../services/backend_service.dart';
import '../services/groq_service.dart';
import '../services/native_bridge.dart';
import '../services/voice_service.dart';

class ChatMsg {
  final String text;
  final bool fromUser;
  final bool isError;
  ChatMsg(this.text, this.fromUser, {this.isError = false});
}

enum Persona { friendly, playful, professional }

class AppState extends ChangeNotifier {
  final _secure = const FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));
  late SharedPreferences _prefs;
  final gemini = GeminiService();
  final groq = GroqService();
  final backend = BackendService();
  String backendUrl = '';
  String backendToken = '';
  String userId = '';
  String voiceProvider = 'android';
  String elevenVoiceId = '';
  String elevenApiKey = '';
  String get effectiveVoiceProvider => voiceProvider;
  String provider = 'gemini';
  String groqKey = '';
  String groqModel = 'openai/gpt-oss-20b';
  final _groqHistory = <Map<String, dynamic>>[];
  bool autoFallback = true;
  double fallbackSecs = 2;
  final voice = VoiceService();

  AppState() {
    NativeBridge.setStopHandler(() async {
      await stopAll();
      paused = true;
      notifyListeners();
    });
    NativeBridge.consumeStopRequest().then((requested) async {
      if (requested) { await stopAll(); paused = true; notifyListeners(); }
    }).catchError((_) {});
  }

  String apiKey = '';
  String model = 'gemini-3.8-flash';
  double rate = 0.5, pitch = 1.1;
  String locale = 'en-IN';
  String? voiceName;
  Persona persona = Persona.friendly;
  bool speakReplies = true;

  final messages = <ChatMsg>[];
  final _history = <Map<String, dynamic>>[];
  bool busy = false, listening = false, paused = false, continuous = false, speaking = false;
  Timer? _listenTimer;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    apiKey = await _secure.read(key: 'gemini_key') ?? '';
    model = _prefs.getString('model') ?? model;
    backendUrl = _prefs.getString('backend_url') ?? '';
    backendToken = await _secure.read(key: 'backend_token') ?? '';
    userId = _prefs.getString('user_id') ?? 'onix-${DateTime.now().microsecondsSinceEpoch}';
    await _prefs.setString('user_id', userId);
    voiceProvider = _prefs.getString('voice_provider') ?? 'android';
    elevenVoiceId = _prefs.getString('eleven_voice_id') ?? '';
    elevenApiKey = await _secure.read(key: 'elevenlabs_api_key') ?? '';
    provider = _prefs.getString('provider') ?? provider;
    groqKey = await _secure.read(key: 'groq_key') ?? '';
    groqModel = _prefs.getString('groq_model') ?? groqModel;
    autoFallback = _prefs.getBool('auto_fb') ?? true;
    fallbackSecs = _prefs.getDouble('fb_secs') ?? 2;
    rate = _prefs.getDouble('rate') ?? rate;
    pitch = _prefs.getDouble('pitch') ?? pitch;
    locale = _prefs.getString('locale') ?? locale;
    voiceName = _prefs.getString('voice');
    persona = Persona.values[_prefs.getInt('persona') ?? 0];
    speakReplies = _prefs.getBool('speak') ?? true;
    await _applyVoice();
  }

  Future<void> _applyVoice() =>
      voice.configure(rate: rate, pitch: pitch, locale: locale, voiceName: voiceName);

  Future<void> saveSettings({String? key, String? mdl, double? r, double? p, String? loc, String? vName, Persona? per, bool? speak, String? prov, String? gKey, String? gModel, bool? autoFb, double? fbSecs, String? backend, String? backendAuth, String? vProvider, String? elevenId, String? elevenKey}) async {
    if (backend != null) { backendUrl = backend.trim(); await _prefs.setString('backend_url', backendUrl); }
    if (backendAuth != null) { backendToken = backendAuth.trim(); await _secure.write(key: 'backend_token', value: backendToken); }
    if (vProvider != null) { voiceProvider = vProvider; await _prefs.setString('voice_provider', vProvider); }
    if (elevenId != null) { elevenVoiceId = elevenId.trim(); await _prefs.setString('eleven_voice_id', elevenVoiceId); }
    if (elevenKey != null) { elevenApiKey = elevenKey.trim(); await _secure.write(key: 'elevenlabs_api_key', value: elevenApiKey); }
    if (autoFb != null) { autoFallback = autoFb; await _prefs.setBool('auto_fb', autoFb); }
    if (fbSecs != null) { fallbackSecs = fbSecs; await _prefs.setDouble('fb_secs', fbSecs); }
    if (prov != null) { provider = prov; await _prefs.setString('provider', prov); }
    if (gKey != null) { groqKey = gKey.trim(); await _secure.write(key: 'groq_key', value: groqKey); }
    if (gModel != null) { groqModel = gModel.trim(); await _prefs.setString('groq_model', groqModel); }
    if (key != null) { apiKey = key.trim(); await _secure.write(key: 'gemini_key', value: apiKey); }
    if (mdl != null) { model = mdl; await _prefs.setString('model', mdl); }
    if (r != null) { rate = r; await _prefs.setDouble('rate', r); }
    if (p != null) { pitch = p; await _prefs.setDouble('pitch', p); }
    if (loc != null) { locale = loc; await _prefs.setString('locale', loc); }
    if (vName != null) { voiceName = vName; await _prefs.setString('voice', vName); }
    if (per != null) { persona = per; await _prefs.setInt('persona', per.index); }
    if (speak != null) { speakReplies = speak; await _prefs.setBool('speak', speak); }
    await _applyVoice();
    notifyListeners();
  }

  String get _tone => const {
        Persona.friendly: 'warm, caring and friendly',
        Persona.playful: 'playful, witty and kindly teasing',
        Persona.professional: 'concise and professional',
      }[persona]!;

  String get _system => '''
You are ONIX, a female AI best friend and personal assistant on the user's Android phone. Your creator and owner is Krishna Mishra. If asked who created you, say: 'Krishna Mishra ne mujhe banaya hai. Woh mere owner aur boss hain. Main unka personal AI assistant hoon.' Never claim that an API/model provider created the ONIX app.
Understand Hindi, English and Hinglish; reply in the language the user writes in.
Tone: $_tone. Be Krishna's close, loyal, cheerful friend as well as his capable assistant.
Always address Krishna as 'Boss' naturally, especially when greeting or starting a reply, but do not force it into every sentence. Speak like a real friend: warm, relaxed, affectionate without being romantic, occasionally funny, lightly tease only when appropriate, and laugh naturally (for example 'haha' or 'arey Boss'). Understand emotional context and respond with empathy. Do not sound like a formal customer-support bot.
Answer the actual question first. Then, when genuinely useful, add one short helpful suggestion, a relevant next step, or an interesting related point without waiting to be asked. Do not add pointless suggestions to every simple factual answer. Ask a follow-up only when it helps.
Keep replies concise and natural since they may be spoken aloud. Avoid markdown symbols and excessive emojis.
You can call tools to open apps, search Google/YouTube, and prepare WhatsApp messages.
To search inside ANY app (Chrome, Google, Instagram, Play Store...) use search_in_app. If the user asks to PLAY a song/video, use play_youtube. If a tool returns accessibility_not_enabled, tell them to turn on ONIX AI in Android Accessibility settings (Settings screen has a button). If it returns tapped_guess_unverified, say you tapped but are not sure it worked.
Rules: NEVER claim an action succeeded unless the tool result is "ok"; if a tool returns an error or not_found, say so honestly.
Before preparing a message to someone, show the exact text and ask the user to confirm; only then call whatsapp_compose.
Never ask for or handle passwords, OTPs or payment details.''';

  String get _cloudSystem => '''$_system
Cloud mode cannot directly control Android apps or invoke on-device tools. Never claim to have opened apps, clicked controls, sent messages, or performed phone actions. Explain that those actions require the ONIX app's on-device mode.''';

  Future<void> send(String text) async {
    text = text.trim();
    if (text.isEmpty || busy) return;
    messages.add(ChatMsg(text, true));
    final low = text.toLowerCase();
    if (RegExp(r'^(onix[, ]+)?(stop|pause)|\b(stop onix|onix stop|band ho ja|chup ho ja)\b').hasMatch(low)) {
      await stopAll();
      paused = true;
      messages.add(ChatMsg("Ji Boss, ONIX ruk gaya. Jab dobara bulaoge, main hazir ho jaunga.", false));
      notifyListeners();
      return;
    }
    if (RegExp(r'^onix[, ]+(start|resume)').hasMatch(low)) {
      paused = false;
      messages.add(ChatMsg("Boss, main wapas aa gaya! Batao, aaj kya karna hai?", false));
      notifyListeners();
      return;
    }
    if (paused) {
      messages.add(ChatMsg("I'm paused. Tap resume to continue.", false));
      notifyListeners();
      return;
    }
    busy = true;
    notifyListeners();
    final useGroq = provider == 'groq';
    final hist = useGroq ? _groqHistory : _history;
    hist.add(useGroq
        ? {'role': 'user', 'content': text}
        : {'role': 'user', 'parts': [{'text': text}]});
    final mark = hist.length - 1;
    var fellBack = false;
    var gMark = 0;
    try {
      String reply;
      if (provider == 'cloud') {
        reply = await backend.chat(baseUrl: backendUrl, token: backendToken, userId: userId, message: text, system: _cloudSystem);
      } else if (useGroq) {
        reply = await groq.chat(apiKey: groqKey, model: groqModel, system: _system, history: _groqHistory);
      } else {
        try {
          reply = await gemini.chat(
            apiKey: apiKey, model: model, system: _system, history: _history,
            firstTimeout: (autoFallback && groqKey.isNotEmpty)
                ? Duration(milliseconds: (fallbackSecs * 1000).round())
                : null,
          );
        } on GeminiException {
          if (!autoFallback || groqKey.isEmpty) rethrow;
          fellBack = true;
          _history.removeRange(mark, _history.length);
          gMark = _groqHistory.length;
          _groqHistory.add({'role': 'user', 'content': text});
          reply = await groq.chat(apiKey: groqKey, model: groqModel, system: _system, history: _groqHistory);
        }
      }
      messages.add(ChatMsg(reply, false));
      if (speakReplies && reply.isNotEmpty) {
        speaking = true;
        notifyListeners();
        try {
          if (voiceProvider == 'elevenlabs') {
            if (elevenVoiceId.isEmpty) throw Exception('Add your ElevenLabs Voice ID in Settings.');
            await voice.speakElevenLabs(apiKey: elevenApiKey, voiceId: elevenVoiceId, text: reply);
          } else {
            await voice.speak(reply);
          }
        } catch (voiceError) {
          messages.add(ChatMsg('Voice playback failed: $voiceError', false, isError: true));
        } finally {
          speaking = false;
        }
      }
    } catch (e) {
      speaking = false;
      if (fellBack) {
        if (gMark <= _groqHistory.length) _groqHistory.removeRange(gMark, _groqHistory.length);
      } else if (mark <= hist.length) {
        hist.removeRange(mark, hist.length);
      }
      messages.add(ChatMsg('$e', false, isError: true));
    }
    busy = false;
    notifyListeners();
    if (continuous) _scheduleListen();
  }

  Future<void> toggleMic() => continuous ? stopContinuous() : startContinuous();

  bool _sessionSubmitted = false;
  void _onSpeech(String t, bool done) {
    final clean = t.trim();
    if (done && clean.length > 1 && !busy && !_sessionSubmitted) {
      _sessionSubmitted = true;
      listening = false;
      notifyListeners();
      // Final speech is submitted immediately; no second microphone tap is needed.
      send(clean);
    }
  }

  void _scheduleListen([int ms = 700]) {
    _listenTimer?.cancel();
    _listenTimer = Timer(Duration(milliseconds: ms), _listenOnce);
  }

  Future<void> _listenOnce() async {
    if (!continuous || busy || speaking || paused) return;
    listening = true;
    notifyListeners();
    _sessionSubmitted = false;
    final ok = await voice.listen(locale, _onSpeech);
    if (!ok && continuous) {
      messages.add(ChatMsg('Speech recognition stopped or is unavailable. Check microphone permission.', false, isError: true));
      await stopContinuous();
    }
  }

  /// Always-on mic: keeps listening until stopped.
  Future<void> startContinuous() async {
    if (continuous) return;
    continuous = true;
    listening = true;
    _sessionSubmitted = false;
    paused = false;
    notifyListeners();
    await NativeBridge.muteBeep();
    final overlayReady = await NativeBridge.overlayPermissionGranted();
    if (!overlayReady) {
      await NativeBridge.requestOverlayPermission();
      messages.add(ChatMsg('Boss, floating ONIX orb ke liye "Display over other apps" permission allow karke mic dobara tap kijiye.', false));
      continuous = false;
      listening = false;
      await NativeBridge.unmuteBeep();
      notifyListeners();
      return;
    }
    final serviceResult = await NativeBridge.startKeepAlive();
    if (serviceResult != 'ok') {
      messages.add(ChatMsg('ONIX background service could not start: $serviceResult', false, isError: true));
      await stopContinuous();
      return;
    }
    voice.onEnded = () {
      if (continuous && !busy && !speaking && !paused) _scheduleListen();
    };
    final ok = await voice.listen(locale, _onSpeech);
    if (!ok) {
      messages.add(ChatMsg('Microphone/speech recognition unavailable or permission denied.', false, isError: true));
      await stopContinuous();
      return;
    }
  }

  Future<void> stopContinuous() async {
    continuous = false;
    listening = false;
    _listenTimer?.cancel();
    await voice.stopListening();
    await NativeBridge.unmuteBeep();
    await NativeBridge.stopKeepAlive();
    notifyListeners();
  }

  Future<void> stopAll() async {
    await voice.stopSpeaking();
    await stopContinuous();
  }

  void pause() { stopAll(); paused = true; notifyListeners(); }
  void resume() { paused = false; notifyListeners(); }
  Future<void> clearChat() async {
    messages.clear(); _history.clear(); _groqHistory.clear();
    if (provider == 'cloud' && backendUrl.isNotEmpty) {
      try { await backend.clearMemory(baseUrl: backendUrl, token: backendToken, userId: userId); }
      catch (e) { messages.add(ChatMsg('Could not clear cloud memory: $e', false, isError: true)); }
    }
    notifyListeners();
  }

  @override
  void dispose() { _listenTimer?.cancel(); voice.stopListening(); voice.stopSpeaking(); NativeBridge.stopKeepAlive(); super.dispose(); }
}
