import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _key;
  late final TextEditingController _model;
  bool _show = false;
  String _status = 'Not tested';
  List<Map<String, String>> _voices = [];

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>();
    _key = TextEditingController(text: s.apiKey);
    _model = TextEditingController(text: s.model);
    _loadVoices();
  }

  Future<void> _loadVoices() async {
    final s = context.read<AppState>();
    final v = await s.voice.voices();
    final lang = s.locale.substring(0, 2).toLowerCase();
    if (mounted) {
      setState(() => _voices = v.where((x) => (x['locale'] ?? '').toLowerCase().startsWith(lang)).toList());
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    const h = TextStyle(fontSize: 18, fontWeight: FontWeight.bold);
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('AI (Gemini)', style: h),
        TextField(
          controller: _key,
          obscureText: !_show,
          decoration: InputDecoration(
              labelText: 'Gemini API key',
              suffixIcon: IconButton(
                  icon: Icon(_show ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() => _show = !_show))),
        ),
        TextField(controller: _model, decoration: const InputDecoration(labelText: 'Model (e.g. gemini-2.5-flash)')),
        const SizedBox(height: 8),
        Row(children: [
          FilledButton(
            onPressed: () async {
              await s.saveSettings(key: _key.text, mdl: _model.text.trim());
              setState(() => _status = 'Testing…');
              final err = await s.gemini.testConnection(s.apiKey);
              setState(() => _status = err == null ? 'Connected ✅' : 'Failed: $err');
            },
            child: const Text('Save & test'),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(_status)),
        ]),
        const Divider(height: 32),
        const Text('Voice', style: h),
        SwitchListTile(
            title: const Text('Speak replies'), value: s.speakReplies, onChanged: (v) => s.saveSettings(speak: v)),
        DropdownButtonFormField<String>(
          value: ['en-IN', 'hi-IN', 'en-US'].contains(s.locale) ? s.locale : 'en-IN',
          decoration: const InputDecoration(labelText: 'Language'),
          items: const [
            DropdownMenuItem(value: 'en-IN', child: Text('English (India) / Hinglish')),
            DropdownMenuItem(value: 'hi-IN', child: Text('Hindi')),
            DropdownMenuItem(value: 'en-US', child: Text('English (US)')),
          ],
          onChanged: (v) async { await s.saveSettings(loc: v); _loadVoices(); },
        ),
        if (_voices.isNotEmpty)
          DropdownButtonFormField<String>(
            value: _voices.any((v) => v['name'] == s.voiceName) ? s.voiceName : null,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Voice (pick a female one)'),
            items: _voices
                .map((v) => DropdownMenuItem(value: v['name'], child: Text(v['name']!, overflow: TextOverflow.ellipsis)))
                .toList(),
            onChanged: (v) => s.saveSettings(vName: v),
          ),
        Text('Speed ${s.rate.toStringAsFixed(2)}'),
        Slider(value: s.rate, min: .2, max: 1, onChanged: (v) => s.saveSettings(r: v)),
        Text('Pitch ${s.pitch.toStringAsFixed(2)}'),
        Slider(value: s.pitch, min: .5, max: 2, onChanged: (v) => s.saveSettings(p: v)),
        OutlinedButton(onPressed: () => s.voice.speak('Hi, main ONIX hoon. Kaise ho?'), child: const Text('Preview voice')),
        const Divider(height: 32),
        const Text('Personality', style: h),
        const SizedBox(height: 8),
        SegmentedButton<Persona>(
          segments: const [
            ButtonSegment(value: Persona.friendly, label: Text('Friendly')),
            ButtonSegment(value: Persona.playful, label: Text('Playful')),
            ButtonSegment(value: Persona.professional, label: Text('Pro')),
          ],
          selected: {s.persona},
          onSelectionChanged: (v) => s.saveSettings(per: v.first),
        ),
        const Divider(height: 32),
        OutlinedButton(onPressed: s.clearChat, child: const Text('Clear conversation')),
        const SizedBox(height: 12),
        const Text(
            'Your API key is kept in Android Keystore-backed secure storage. A key bundled in a distributed APK can be extracted — use a backend proxy for production.',
            style: TextStyle(color: Colors.white54, fontSize: 12)),
      ]),
    );
  }
}
