import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_state.dart';
import '../services/native_bridge.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _key;
  late final TextEditingController _model;
  late final TextEditingController _gkey;
  late final TextEditingController _gmodel;
  late final TextEditingController _backend;
  late final TextEditingController _backendToken;
  late final TextEditingController _elevenId;
  late final TextEditingController _elevenKey;
  bool _show = false;
  bool _a11y = false;
  String _status = 'Not tested';

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>();
    _key = TextEditingController(text: s.apiKey);
    _model = TextEditingController(text: s.model);
    _gkey = TextEditingController(text: s.groqKey);
    _gmodel = TextEditingController(text: s.groqModel);
    _backend = TextEditingController(text: s.backendUrl);
    _backendToken = TextEditingController(text: s.backendToken);
    _elevenId = TextEditingController(text: s.elevenVoiceId);
    _elevenKey = TextEditingController(text: s.elevenApiKey);
    NativeBridge.a11yEnabled().then((v) => mounted ? setState(() => _a11y = v) : null);
  }


  @override
  void dispose() { _key.dispose(); _model.dispose(); _gkey.dispose(); _gmodel.dispose(); _backend.dispose(); _backendToken.dispose(); _elevenId.dispose(); _elevenKey.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    const h = TextStyle(fontSize: 18, fontWeight: FontWeight.bold);
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('AI provider', style: h),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'groq', label: Text('Groq (fast)')),
            ButtonSegment(value: 'gemini', label: Text('Gemini')),
            ButtonSegment(value: 'cloud', label: Text('ONIX Cloud')),
          ],
          selected: {s.provider},
          onSelectionChanged: (v) => s.saveSettings(prov: v.first),
        ),
        if (s.provider == 'cloud') ...[
          TextField(controller: _backend, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'ONIX Backend URL', hintText: 'https://your-onix-api.example.com')),
          TextField(controller: _backendToken, obscureText: true, decoration: const InputDecoration(labelText: 'Backend access token')), 
          const Padding(padding: EdgeInsets.only(top: 8), child: Text('Cloud mode keeps Gemini/Groq keys on your backend and stores conversation memory there. Deploy the backend folder first.', style: TextStyle(color: Colors.white60, fontSize: 12))),
        ] else if (s.provider == 'groq') ...[
          TextField(
            controller: _gkey,
            obscureText: !_show,
            decoration: InputDecoration(
                labelText: 'Groq API key',
                suffixIcon: IconButton(
                    icon: Icon(_show ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => _show = !_show))),
          ),
          TextField(controller: _gmodel, decoration: const InputDecoration(labelText: 'Groq model (e.g. openai/gpt-oss-20b)')),
        ] else ...[
          TextField(
            controller: _key,
            obscureText: !_show,
            decoration: InputDecoration(
                labelText: 'Gemini API key',
                suffixIcon: IconButton(
                    icon: Icon(_show ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => _show = !_show))),
          ),
          TextField(controller: _model, decoration: const InputDecoration(labelText: 'Gemini model')),
        ],
        if (s.provider == 'gemini') ...[
          SwitchListTile(
            title: const Text('Auto-switch to Groq if Gemini fails'),
            value: s.autoFallback,
            onChanged: (v) => s.saveSettings(autoFb: v),
          ),
          if (s.autoFallback) ...[
            Text('Switch after ${s.fallbackSecs.toStringAsFixed(1)} s (needs Groq key)'),
            Slider(value: s.fallbackSecs, min: 1, max: 10, divisions: 18, onChanged: (v) => s.saveSettings(fbSecs: v)),
          ],
        ],
        const SizedBox(height: 8),
        Row(children: [
          FilledButton(
            onPressed: () async {
              if (s.provider == 'cloud') {
                await s.saveSettings(backend: _backend.text, backendAuth: _backendToken.text);
              } else if (s.provider == 'groq') {
                await s.saveSettings(gKey: _gkey.text, gModel: _gmodel.text);
              } else {
                await s.saveSettings(key: _key.text, mdl: _model.text.trim());
              }
              setState(() => _status = 'Testing…');
              final err = s.provider == 'cloud'
                  ? await s.backend.test(s.backendUrl)
                  : s.provider == 'groq'
                      ? await s.groq.testConnection(s.groqKey)
                      : await s.gemini.testConnection(s.apiKey);
              setState(() => _status = err == null ? 'Connected ✅' : 'Failed: $err');
            },
            child: const Text('Save & test'),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(_status)),
        ]),
        const Divider(height: 32),
        const Text('Voice', style: h),
        const ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text('Voice engine: ElevenLabs'),
          subtitle: Text('ONIX replies use your selected ElevenLabs voice. Android/Google default TTS is not used for assistant replies.'),
        ),
        if (s.voiceProvider == 'elevenlabs') ...[
          TextField(controller: _elevenId, decoration: const InputDecoration(labelText: 'ElevenLabs Voice ID', helperText: 'Paste the Voice ID from your ElevenLabs voice library.')),
          TextField(controller: _elevenKey, obscureText: true, decoration: const InputDecoration(labelText: 'ElevenLabs API Key', helperText: 'From ElevenLabs Profile → API Keys. Stored securely on this phone.')),
          const Padding(padding: EdgeInsets.only(top: 4), child: Text('Voice ID selects the voice; API key authenticates your account. Both are required. This direct mode does not need an ONIX backend URL. Keep your API key private.', style: TextStyle(color: Colors.white60, fontSize: 12))),
          OutlinedButton(onPressed: () async { await s.saveSettings(elevenId: _elevenId.text, elevenKey: _elevenKey.text, vProvider: 'elevenlabs'); if (mounted) setState(() => _status = 'Testing ElevenLabs…'); try { await s.voice.speakElevenLabs(apiKey: s.elevenApiKey, voiceId: s.elevenVoiceId, text: 'Hi, main ONIX hoon. Kaise ho?'); if (mounted) setState(() => _status = 'ElevenLabs voice connected ✓'); } catch (e) { if (mounted) setState(() => _status = 'Voice test failed: $e'); } }, child: const Text('Save & test ElevenLabs voice')),
        ],
        SwitchListTile(
            title: const Text('Speak replies'), value: s.speakReplies, onChanged: (v) => s.saveSettings(speak: v)),
        DropdownButtonFormField<String>(
          value: ['en-IN', 'hi-IN', 'en-US'].contains(s.locale) ? s.locale : 'en-IN',
          decoration: const InputDecoration(labelText: 'Language'),
          items: const [
            DropdownMenuItem(value: 'en-IN', child: Text('English (India) / Hinglish')),
            DropdownMenuItem(value: 'hi-IN', child: Text('Hindi')),
            DropdownMenuItem(value: 'en-US', child: Text('English (US)')),
          ],
          onChanged: (v) => s.saveSettings(loc: v),
        ),
        OutlinedButton(onPressed: () async { try { await s.voice.speakElevenLabs(apiKey: s.elevenApiKey, voiceId: s.elevenVoiceId, text: 'Hi, main ONIX hoon. Kaise ho?'); } catch (e) { if (mounted) setState(() => _status = 'Voice preview failed: $e'); } }, child: const Text('Preview ElevenLabs voice')),
        const Text('Automation', style: h),
        ListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Accessibility Service (auto-click / typing)'),
          subtitle: Text(_a11y ? 'Enabled ✅' : 'Not enabled — tap to turn on ONIX AI'),
          trailing: IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => NativeBridge.a11yEnabled().then((v) => setState(() => _a11y = v)),
          ),
          onTap: NativeBridge.openA11ySettings,
        ),
        const Divider(height: 32),
        const Text('Personality', style: h),
        const SizedBox(height: 8),
        SegmentedButton<Persona>(
          segments: const [
            ButtonSegment(value: Persona.friendly, label: Text('Friendly')),
            ButtonSegment(value: Persona.playful, label: Text('Playful')),
            ButtonSegment(value: Persona.professional, label: Text('Pro')),
          ],
          selected: {s.persona},
          onSelectionChanged: (v) => s.saveSettings(per: v.first),
        ),
        const Divider(height: 32),
        OutlinedButton(onPressed: s.clearChat, child: const Text('Clear conversation')),
        const SizedBox(height: 12),
        const Text(
            'Direct-mode API keys are stored in Android Keystore-backed storage, but can still be extracted from a distributed app. ONIX Cloud mode keeps provider secrets on your backend.',
            style: TextStyle(color: Colors.white54, fontSize: 12)),
      ]),
    );
  }
}
