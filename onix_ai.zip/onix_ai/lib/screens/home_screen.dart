import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_state.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _ctl = TextEditingController();
  final _scroll = ScrollController();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cs = Theme.of(context).colorScheme;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: ShaderMask(
          shaderCallback: (r) => LinearGradient(colors: [cs.primary, cs.secondary]).createShader(r),
          child: const Text('ONIX AI', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 3)),
        ),
        actions: [
          IconButton(
            tooltip: s.paused ? 'Resume' : 'Stop ONIX',
            icon: Icon(s.paused ? Icons.play_arrow : Icons.stop_circle_outlined),
            onPressed: () => s.paused ? s.resume() : s.pause(),
          ),
          IconButton(
              icon: const Icon(Icons.settings),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: s.messages.isEmpty
              ? Center(
                  child: Text('Say hi to ONIX 💜\nTry: "Instagram kholo"',
                      textAlign: TextAlign.center, style: TextStyle(color: cs.secondary)))
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.all(12),
                  itemCount: s.messages.length,
                  itemBuilder: (_, i) {
                    final m = s.messages[i];
                    return Align(
                      alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.all(12),
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .8),
                        decoration: BoxDecoration(
                          color: m.isError
                              ? Colors.red.withOpacity(.2)
                              : (m.fromUser ? cs.primary.withOpacity(.25) : Colors.white.withOpacity(.07)),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: (m.fromUser ? cs.primary : cs.secondary).withOpacity(.3)),
                        ),
                        child: SelectableText(m.text),
                      ),
                    );
                  }),
        ),
        if (s.busy) LinearProgressIndicator(color: cs.secondary, backgroundColor: Colors.black),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              IconButton.filled(
                style: IconButton.styleFrom(backgroundColor: s.listening ? cs.secondary : cs.primary),
                icon: Icon(s.listening ? Icons.mic : Icons.mic_none),
                onPressed: s.toggleMic,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _ctl,
                  onSubmitted: (v) { s.send(v); _ctl.clear(); },
                  decoration: InputDecoration(
                      hintText: 'Message ONIX…',
                      filled: true,
                      fillColor: Colors.white10,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
                ),
              ),
              IconButton(icon: const Icon(Icons.send), onPressed: () { s.send(_ctl.text); _ctl.clear(); }),
            ]),
          ),
        ),
      ]),
    );
  }
}
