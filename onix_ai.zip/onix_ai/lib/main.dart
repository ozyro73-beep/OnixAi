import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/app_state.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.load();
  runApp(ChangeNotifierProvider.value(value: state, child: const OnixApp()));
}

class OnixApp extends StatelessWidget {
  const OnixApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ONIX AI',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: Colors.black,
          colorScheme: const ColorScheme.dark(
              primary: Color(0xFF9B5CFF), secondary: Color(0xFF00E5FF)),
          useMaterial3: true,
        ),
        home: const HomeScreen(),
      );
}
