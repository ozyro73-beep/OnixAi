# ONIX AI (v0.1 – first working slice)

## Implemented
- Gemini REST service (retry, timeout, connection test) with real function calling: open_app, web_search, youtube_search, whatsapp_compose
- Chat UI, speech-to-text, text-to-speech (voice/speed/pitch/language), interrupt/stop, "onix stop / resume"
- Secure API-key storage (Keystore-backed), persona modes, settings

## NOT implemented yet
Accessibility-service typing, memory screen, reminders/alarms, coding mode, history screen, wake word, foreground service, screenshot understanding, local DB.

## Build (Termux or any machine with Flutter)
1. Open this folder in a shell with Flutter installed
2. `./setup.sh`
3. `flutter build apk --debug`

## Status
Source NOT compiled. APK build NOT verified.
WhatsApp: opens a prefilled message; you pick the contact and tap Send (nothing is sent automatically).
Security: a key in a distributed APK can be extracted — use a backend proxy for production.
