# ONIX AI

Flutter Android personal assistant with Gemini/Groq AI, on-device Android actions, continuous in-app voice chat, and optional ONIX cloud gateway.

## Included

- Existing chat UI, app launching, Google/YouTube search, WhatsApp message preparation, and accessibility actions.
- Gemini and Groq direct modes, optional cloud gateway, conversation history, and provider fallback.
- Continuous in-app speech recognition: recognized utterances are submitted to the same ONIX chat flow and listening restarts after the reply.
- Assistant speech is ElevenLabs-only. There is no Android/Google Text-to-Speech fallback. Add an ElevenLabs Voice ID and API key in Settings.
- Listening-start beep and native beep generator have been removed.
- Heed `Hey ONIX` model files are included under `assets/wakeword/`.

## Important status: Hey ONIX wake word

The model and metadata are bundled, but the Android streaming microphone capture, Heed signal preprocessing (high-pass/notch, log-mel, CMN), ONNX Runtime inference loop, and native foreground-service wake trigger are **not yet implemented in this source revision**. Building this ZIP does not yet activate the Hey ONIX wake phrase. This must be completed and tested before calling it wake-word enabled. The model's reported validation accuracy came from synthetic validation data and is not a real-phone guarantee.

The current foreground service supports the user-started in-app voice session only; the speech recognition loop is still Flutter-Activity-owned. It is not an always-on independent wake-word engine. Android/OEM battery controls can interrupt background microphone work. No microphone feature can continue after force-stop, uninstall, permission revocation, or OS termination.

## Voice behavior

- Tap the mic to start a hands-free in-app voice session.
- Speak naturally; the recognized final utterance goes to ONIX chat automatically.
- ONIX speaks the reply using ElevenLabs, then listens again while continuous mode remains active.
- No start beep and no Google/Android TTS fallback.
- Speech-to-text still uses Android's configured speech-recognition service through Flutter `speech_to_text`; this is separate from text-to-speech. This source does not include a local offline speech-to-text model.
- AI and ElevenLabs require internet. The wake model itself is local, but its Android inference pipeline is still pending.

## Build locally

Requires Flutter stable, Android SDK, and Java 17:

```bash
bash setup.sh
flutter build apk --debug
```

## Build on GitHub

A workflow is included at `.github/workflows/android.yml`. Upload the repository to GitHub and push to `main`/`master`, or run **Actions → Build ONIX Android APK → Run workflow**. Download the `onix-ai-debug-apk` artifact from the completed workflow.

This workflow builds the current source; it does not imply that the unfinished Hey ONIX native inference engine is active.

## Configure AI and voice

Open Settings and select Gemini or Groq. Add the corresponding API key and tap **Save & test**. For spoken replies, add both ElevenLabs Voice ID and API key and use **Save & test ElevenLabs voice**. API keys are stored using Android secure storage. For production distribution, a backend is safer than embedding provider credentials in a mobile app.

## Optional ONIX Cloud backend

The FastAPI backend is in `backend/`. Configure `ONIX_ACCESS_TOKEN`, `GEMINI_API_KEY`, and optionally `GROQ_API_KEY` and `ELEVENLABS_API_KEY` in the hosting provider's secret manager. Deploy with HTTPS and persistent storage for SQLite. Never commit real API keys or access tokens.

## Validation

Flutter and Android SDK are not installed in the editing environment, so no APK build or device test has been performed here. The GitHub Actions workflow is included to perform the build. Android speech recognition, ElevenLabs playback, accessibility actions, and all app behavior still require real-device testing.

## Heed model attribution

The wake-word model was exported using [Heed Wake Word](https://github.com/AndreiBulzan/heed-wakeword), an Apache-2.0 project. The model files are the user's own trained `Hey ONIX` export. Keep the upstream license/attribution when distributing the model integration.
