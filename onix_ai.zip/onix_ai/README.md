# ONIX AI

Flutter Android personal assistant with on-device Android actions, continuous voice mode, Gemini/Groq direct mode, and an optional ONIX cloud gateway.

## Included in this source

- Existing chat UI, app launching, Google/YouTube search, WhatsApp message preparation, accessibility actions.
- Direct Gemini and Groq provider modes. Gemini is set to `gemini-3.8-flash` by default; model IDs can be changed in Settings.
- Gemini-to-Groq fallback on provider errors/timeouts when enabled and a Groq key is configured.
- Optional ONIX Cloud mode: FastAPI gateway, Gemini primary/Groq fallback, per-install conversation memory, protected endpoints, and server-side provider credentials.
- Android TTS and optional ElevenLabs speech through the cloud gateway. ElevenLabs credentials stay on the backend.
- Continuous speech recognition with duplicate-final-result protection, automatic restart, and a foreground notification with a STOP ONIX action.
- ONIX owner identity prompt: Krishna Mishra. The model/API vendor is not represented as the creator of the ONIX app.

## Build the Android APK

Requires Flutter stable, Android SDK, and Java 17. From this folder:

```bash
./setup.sh
flutter build apk --release
```

The GitHub Actions workflow in the repository can build the APK without installing Flutter on your phone. The build artifact is `app-release.apk` if you configure the workflow for release, or `app-debug.apk` for the current debug workflow.

## Direct AI mode

Open Settings and select Gemini or Groq. Add the provider key and tap **Save & test**. Direct-mode keys are stored using Android secure storage, but a determined attacker can still extract secrets from a distributed mobile app. Use Cloud mode for production.

## Deploy ONIX Cloud backend

The backend source is in `backend/`. It is a separate service from the Android APK.

1. Deploy `backend/` as a Docker web service on a host that supports a persistent disk (for example, attach a persistent volume and set `ONIX_DB` to a file on that volume). Do not use the container's ephemeral filesystem for long-term SQLite memory.
2. Set these environment variables in the hosting dashboard / secret manager:
   - `ONIX_ACCESS_TOKEN`: a long random secret shared with the app.
   - `GEMINI_API_KEY`: server-side Gemini key.
   - `GROQ_API_KEY`: server-side Groq key (backup).
   - `PRIMARY_PROVIDER=gemini`
   - `GEMINI_MODEL=gemini-3.8-flash`
   - `GROQ_MODEL=openai/gpt-oss-20b`
   - Optional `ELEVENLABS_API_KEY` and `ELEVENLABS_MODEL=eleven_multilingual_v2`.
   - `ONIX_DB=/data/onix_memory.sqlite3` when your host mounts a persistent disk at `/data`.
3. Expose the service over HTTPS. Confirm `https://YOUR-HOST/health` returns `{"status":"ok"...}`.
4. In ONIX Settings select **ONIX Cloud**, enter the backend HTTPS URL and the same `ONIX_ACCESS_TOKEN`, then tap **Save & test**.
5. For ElevenLabs, select it under Voice provider, enter the same backend URL/token and your ElevenLabs Voice ID, then save/test. The ElevenLabs API key belongs only in the backend environment.

Run locally for development:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export ONIX_ACCESS_TOKEN='replace-with-a-long-random-secret'
export GEMINI_API_KEY='your-gemini-key'
export GROQ_API_KEY='your-groq-key'
uvicorn main:app --host 0.0.0.0 --port 8080
```

Cloud mode currently provides chat and server-side conversation memory. Android-only actions (opening apps, tapping, typing) remain on-device and are intentionally not claimed as available to the cloud model. SQLite is suitable for a single-instance prototype; use a persistent disk and backups for deployment. Do not expose the backend without HTTPS and a strong access token.

## Android voice limitations

Continuous listening is user-started and shows a persistent foreground notification while active. Android/OEM battery rules and speech-recognition provider behavior can still interrupt listening. It cannot continue after force-stop, uninstall, permission revocation, or a system kill; background microphone access is subject to Android's foreground-service and microphone permission rules. The STOP ONIX notification action stops the listening session and marks ONIX paused.

## Important

This source has not been built on the current editing environment because Flutter/Android SDK are not installed here. Run the GitHub Actions build and share the first failing log if anything fails; do not treat this ZIP as a verified APK.


## ElevenLabs voice (direct from the app)
Choose **ElevenLabs (direct)** in Settings, then enter both your ElevenLabs Voice ID and API key and tap **Save & test ElevenLabs voice**. The Voice ID selects the voice; the API key authenticates your ElevenLabs account. The key is stored using Android secure storage and is not bundled as a source-code constant. Direct mode does not require an ONIX backend URL.

Create an API key in your ElevenLabs account under Profile / API Keys. Keep it private. A Voice ID alone cannot authorize text-to-speech requests.
